import java.io.*;

public class Employee implements Serializable
{
	private int empId;
	private String empName, dept;
	private Laptop laptop;
	
	public Employee(int empId, String empName, String dept, Laptop laptop) 
	{
		this.empId = empId;
		this.empName = empName;
		this.dept = dept;
		this.laptop = laptop;
	}

	public String toString()
	{
		return "\nEMPLOYEE ID : "+this.getEmpId()+"\nEMPLOYEE NAME : "+this.getEmpName()+"\nDEPARTMENT : "+this.getDept()+"\n\nLAPTOP ASSIGNED : "+this.laptop.toString();
	}
	
	public int getEmpId() {	return empId;	}

	public String getEmpName() {	return empName;	}

	public String getDept() {	return dept;	}
	
	public Laptop getLaptop() {	return laptop;	}

	public void setLaptop(Laptop laptop) {	this.laptop = laptop;	}
}
