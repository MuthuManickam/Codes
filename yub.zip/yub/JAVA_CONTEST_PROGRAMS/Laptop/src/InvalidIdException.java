
public class InvalidIdException extends Exception
{
	InvalidIdException(String msg)
	{
		super(msg);
	}
}
