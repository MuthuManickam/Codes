import java.util.*;
import java.io.*;

public class Main implements Serializable
{
	public static void main(String args[]) throws InvalidIdException, IOException
	{
		int ch=1;
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("WELCOME ... \n");
		
		do
		{
			System.out.println();
			System.out.println("1. ADD DETAILS");
			System.out.println("2. DISPLAY DETAILS");
			System.out.println("3. REMOVE DETAILS");
			System.out.println("4. EXIT");
			
			System.out.print("\nENTER YOUR CHOICE : ");
			ch = sc.nextInt();
			
			if(ch == 1)
			{
				int empId;
				String laptopId, hostName, make, empName, dept;
				
				System.out.print("\nENTER EMPLOYEE NAME : ");	empName = sc.next();
				System.out.print("ENTER EMPLOYEE ID : ");		empId = sc.nextInt();
				System.out.print("ENTER EMPLOYEE DEPT. : ");	dept = sc.next();
				System.out.print("ENTER LAPTOP ID : ");			laptopId = sc.next();
				System.out.print("ENTER HOST NAME : ");			hostName = sc.next();
				System.out.print("ENTER MAKE : ");				make = sc.next();
				
				Laptop ll = new Laptop(laptopId, hostName, make);	
				Employee ee = new Employee(empId, empName, dept, ll);
				ll.setStatus("ASSIGNED");
				
				ManageEmployee.addEmployee(ee);
			}
			
			if(ch == 2)
			{
				if(!ManageEmployee.emps.isEmpty())
				{
					Iterator ii = ManageEmployee.emps.iterator();
					
					while(ii.hasNext())
					{
						Employee ee = (Employee) ii.next();
						System.out.println(ee);
					}
				}
				else
				{
					System.out.println("\nLIST IS EMPTY, ADD EMPLOYEE FIRST");
				}
			}
			
			if(ch == 3)
			{
				System.out.print("\nENTER EMPLOYEE ID : ");
				int empId = sc.nextInt();
				ManageEmployee.removeEmployee(empId);
			}
			
			if(ch == 4)
			{
				try
				{
					fos = new FileOutputStream("E:\\details.txt", true);
					oos = new ObjectOutputStream(fos);
					oos.writeObject(ManageEmployee.emps);
					System.out.println("\nOBJECT STATE RECORDED SUCCESSFULLY ...");
				}
				catch(IOException ioe)
				{
					ioe.printStackTrace();
					System.out.println(ioe.getMessage());
				}
							
				System.out.println("\nTHANK YOU !!!");
				System.exit(0);
			}
			if(ch<0 || ch>4)
			{
				System.out.println("\nWRONG CHOICE. PROGRAM WILL TERMINATE NOW...");
				System.exit(1);
			}
		}while(ch!=4);
		
		fos.close();
		oos.close();
	}
}
