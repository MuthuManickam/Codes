import java.io.*;

public class Laptop implements Serializable
{
	private String laptopId, hostName, make, status;

	public Laptop(String laptopId, String hostName, String make)	throws InvalidIdException
	{
		if(laptopId.startsWith("L") && Character.isDigit(laptopId.charAt(1)) && Character.isDigit(laptopId.charAt(2)) && Character.isDigit(laptopId.charAt(3)) && laptopId.length() == 4)
		{
			this.laptopId = laptopId;
			this.hostName = hostName;
			this.make = make;
		}
		else
			throw new InvalidIdException("LAPTOP ID IS INCORRECT !");
	}
	
	public String getLaptopId() {	return laptopId;	}

	public String getHostName() {	return hostName;	}

	public String getMake() {	return make;	}
	
	public String getStatus() {	return status;	}

	public void setStatus(String status) {	this.status = status;	}

	public String toString()	
	{
		return "\nLAPTOP ID : "+this.getLaptopId()+"\nHOST NAME : "+this.getHostName()+"\nLAPTOP MAKE : "+this.getMake()+"\nSTATUS : "+this.status;
	}
}
