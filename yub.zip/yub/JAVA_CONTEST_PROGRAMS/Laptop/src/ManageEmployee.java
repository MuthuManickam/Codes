import java.io.*;
import java.util.*;

public class ManageEmployee implements Serializable
{
	static ArrayList<Employee> emps = new ArrayList<Employee>();
	
	static void addEmployee(Employee e)
	{
		emps.add(e);
		System.out.println("\nEMPLOYEE ADDED SUCCESSFULLY");
	}
	
	static boolean removeEmployee(int empId)
	{
		boolean bb = false;
		
		if(!emps.isEmpty())
		{
			for(int i=0; i<emps.size(); i++)
			{
				Employee ee = emps.get(i);
				if(ee.getEmpId() == empId)
				{
					ee.getLaptop().setStatus("NOT ASSIGNED");
					emps.remove(i);
					System.out.println("\nEMPLOYEE REMOVED SUCCESSFULLY");
					bb = true;
					break;
				}
				else
				{
					System.out.println("\nEMPLOYEE NOT FOUND");
					bb = false;
				}
			}
		}
		else
		{
			System.out.println("\nLIST IS EMPTY, ADD EMPLOYEE FIRST");
			bb = false;
		}
		
		return bb;
	}
}
