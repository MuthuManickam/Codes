
public class Circle extends Shape
{
	double radius;
	
	Circle()	{	}
	
	Circle(double radius)
	{
		this.radius = radius;
	}
	
	void draw()
	{
		System.out.println("CIRCLE DRAW SUCCESSFULL");
	}
	
	double area()
	{
		return 3.14*Math.pow(radius, 2);
	}
	
	void display()
	{
		System.out.println("THE AREA OF CIRCLE : "+this.area()+" sq. units");
	}
}