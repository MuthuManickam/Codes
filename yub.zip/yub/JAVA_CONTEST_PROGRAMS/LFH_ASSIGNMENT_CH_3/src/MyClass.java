
public class MyClass 
{
	public static void main(String[] args) 
	{		
		Manager mm = new Manager("Akash", "M001", 30000, "FINANCIAL");
		System.out.println("MANAGER NAME : "+mm.getName());
		System.out.println("MANAGER ID : "+mm.empId);
		System.out.println("MANAGER SALARY : Rs. "+mm.getSalary());
		System.out.println("MANAGER TYPE : "+mm.type);
		
		System.out.println();
		
		Clerk cc = new Clerk("Narayan", "C001", 20000, 50, 75);
		System.out.println("CLERK NAME : "+cc.getName());
		System.out.println("CLERK ID : "+cc.empId);
		System.out.println("CLERK SALARY : Rs. "+cc.getSalary());
		System.out.println("CLERK SPEED : "+cc.speed+" WpH");
		System.out.println("CLERK ACCURACY : "+cc.accuracy+" %");
	}
}