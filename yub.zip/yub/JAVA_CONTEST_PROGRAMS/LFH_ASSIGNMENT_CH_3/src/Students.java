abstract class Students
{
	String name, standard;
	static int  noOfStudents = 0;
	
	abstract double getPercentage();
	
	static int getTotalNoStudents()	{	return noOfStudents;	}
	
	Students()	{	}
	
	Students(String name, String standard)
	{
		this.name = name;
		this.standard = standard;
	}
}