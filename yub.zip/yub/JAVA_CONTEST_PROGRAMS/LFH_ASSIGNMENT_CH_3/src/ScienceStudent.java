class ScienceStudent extends Students
{
	int physicsMarks = 0, chemistryMarks = 0, mathsMarks = 0;
	static int noOfStudents = 0;
	double percentage = 0;
	
	ScienceStudent()	{	}
	
	ScienceStudent(int physicsMarks, int chemistryMarks, int mathsMarks)
	{
		if(((physicsMarks <= 100) && (physicsMarks >= 0)) && ((chemistryMarks <= 100) && (chemistryMarks >= 0)) && ((mathsMarks <= 100) && (mathsMarks >= 0)))
		{
			this.physicsMarks = physicsMarks;
			this.chemistryMarks = chemistryMarks;
			this.mathsMarks = mathsMarks;
			

			Students.noOfStudents++;
		}
		else
		{
			System.out.println("CHECK SCIENCE MARKS !!!");
		}
	}
	
	double getPercentage()
	{
		double percentage = 0;
		int total = this.physicsMarks + this.chemistryMarks + this.mathsMarks;
		percentage = (total*(0.33));	//	100/300 = 0.33
			
		return percentage;
	}
}