
public class Manager extends Employee
{
	String type;

	Manager(String name, String empId, int salary, String type) 
	{
		super(name, empId, salary);
		this.type = type;
	}

	public String getType() 
	{
		return type;
	}

	public void setType(String type) 
	{
		this.type = type;
	}
	
	public void setSalary(int salary) 
	{
		this.salary = salary;
	}	
}