
public class Employee 
{
	String name, empId;
	int salary;
	
	Employee(String name, String empId, int salary) 
	{
		this.name = name;
		this.empId = empId;
		this.salary = salary;
	}

	public String getName() 
	{
		return name;
	}
	
	public void setName(String name) 
	{
		this.name = name;
	}
	
	public String getEmpId() 
	{
		return empId;
	}
	
	public void setEmpId(String empId) 
	{
		this.empId = empId;
	}
	
	public int getSalary() 
	{
		return salary;
	}
	
	public void setSalary(int salary) 
	{
		this.salary = salary;
	}	
}