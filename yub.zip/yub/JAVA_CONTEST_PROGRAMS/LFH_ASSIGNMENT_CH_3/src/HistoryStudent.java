class HistoryStudent extends Students
{
	int historyMarks = 0, civicsMarks = 0;
	static int noOfStudents = 0;
	
	HistoryStudent()	{	}
	
	HistoryStudent(int historyMarks, int civicsMarks)
	{
		if(((historyMarks <= 100) && (historyMarks >= 0)) && ((civicsMarks <= 100) && (civicsMarks >= 0)))
		{
			this.historyMarks = historyMarks;
			this.civicsMarks = civicsMarks;

			Students.noOfStudents++;
		}
		else
		{
			System.out.println("CHECK HISTORY MARKS !!!");
		}
	}
	
	double getPercentage()
	{
		double percentage = 0;
		int total = this.historyMarks + this.civicsMarks;
		percentage = (total*0.5);	//	100/200 = 0.5
			
		return percentage;
	}
}