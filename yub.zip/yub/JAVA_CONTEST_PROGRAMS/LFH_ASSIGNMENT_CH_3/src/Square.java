
public class Square extends Shape
{
	double side;
	
	Square()	{	}
	
	Square(double side)
	{
		this.side = side;
	}
	
	void draw()
	{
		System.out.println("SQUARE DRAW SUCCESSFULL");
	}
	
	double area()
	{
		return Math.pow(side, 2);
	}
	
	void display()
	{
		System.out.println("THE AREA OF SQUARE : "+this.area()+" sq. units");
	}
}