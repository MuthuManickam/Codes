
public abstract class Shape extends Object 
{
	abstract void draw();
	
	abstract double area();
	
	abstract void display();
}