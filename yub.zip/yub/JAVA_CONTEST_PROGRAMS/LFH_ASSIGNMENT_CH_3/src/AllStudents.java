public class AllStudents
{
	public static void main(String args[]) 
	{
		ScienceStudent ss = new ScienceStudent(75,80,85);
		HistoryStudent hs = new HistoryStudent(75,95);
		
		System.out.println("TOTAL NO OF STUDENTS : "+Students.getTotalNoStudents());
		System.out.println();
		
		System.out.println("SCIENCE STUDENT %AGE : "+ss.getPercentage()+" %");
		System.out.println("HISTORY STUDENT %AGE : "+hs.getPercentage()+" %");
	}
}