
public class Rectangle extends Shape
{
	double length, breadth;
	
	Rectangle()	{	}
	
	Rectangle(double length, double breadth)
	{
		this.length = length;
		this.breadth = breadth;
	}
	
	void draw()
	{
		System.out.println("RECTANGLE DRAW SUCCESSFULL");
	}
	
	double area()
	{
		return length*breadth;
	}
	
	void display()
	{
		System.out.println("THE AREA OF RECTAGLE : "+this.area()+" sq. units");
	}
}
