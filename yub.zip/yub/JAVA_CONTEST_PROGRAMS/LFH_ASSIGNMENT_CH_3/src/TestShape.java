
public class TestShape 
{
	public static void main(String args[]) 
	{
		Rectangle rr = new Rectangle(20,30);
		rr.draw();
		
		Circle cc = new Circle(20);
		cc.draw();
		
		Square ss = new Square(5);
		ss.draw();
		
		rr.display();
		cc.display();
		ss.display();
	}
}
