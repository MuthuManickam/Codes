package broadband;

import java.util.*;

public class ServiceProvider implements BroadbandConnection
{
	public ArrayList<Customer> custDetails = new ArrayList<Customer>();
	
	public boolean activate(Customer c)
	{
		custDetails.add(c);
		
		if(custDetails.contains(c))
			return true;
		else
			return false;
	}
	
	public boolean deActivate(Customer c)
	{
		if(!custDetails.isEmpty())
		{
			if(custDetails.contains(c))
			{
				custDetails.remove(c);
				return true;
			}
			
			return false;
		}
		else
			return false;
	}
	
	public int getCountByPlanType(String type)
	{
		int count = 0;
		
		if(!custDetails.isEmpty())
		{
			for(int i=0; i<custDetails.size(); i++)
			{
				Customer cc = custDetails.get(i);
				if(cc.getPlan().getPlanType().equalsIgnoreCase(type))
					count++;
			}
		}
		
		return count;
	}
	
	public int getCountByPlanName(String planName)
	{
		int count = 0;
		
		if(!custDetails.isEmpty())
		{
			for(int i=0; i<custDetails.size(); i++)
			{
				Customer cc = custDetails.get(i);
				if(cc.getPlan().getPlanName().equalsIgnoreCase(planName))
					count++;	
			}
		}
		
		return count;
	}
}
