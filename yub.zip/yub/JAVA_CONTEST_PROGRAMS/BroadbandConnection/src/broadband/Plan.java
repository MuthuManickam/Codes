package broadband;

public class Plan 
{
	private String planName, planType;
	private int baseCharge;
	
	public Plan(String planName, String planType, int baseCharge)	throws InvalidPlanTypeException 
	{
		if(planType.equals("LimitedPlan") || planType.equals("UnlimitedPlan"))
		{
			this.planName = planName;
			this.planType = planType;
			this.baseCharge = baseCharge;
		}
		else
			throw new InvalidPlanTypeException("PLAN TYPE IS INVALID");
	}

	public String getPlanName() {	return planName;	}

	public void setPlanName(String planName) {	this.planName = planName;	}

	public String getPlanType() {	return planType;	}

	public void setPlanType(String planType) {	this.planType = planType;	}

	public int getBaseCharge() {	return baseCharge;	}

	public void setBaseCharge(int baseCharge) {	this.baseCharge = baseCharge;	}
}