package broadband;

public class InvalidPlanTypeException extends Exception 
{
	InvalidPlanTypeException(String msg)
	{
		super(msg);
	}
}
