package broadband;

public interface BroadbandConnection 
{
	public boolean activate(Customer c);
	
	public boolean deActivate(Customer c);
	
	public int getCountByPlanType(String planType);
	
	public int getCountByPlanName(String planName);
}
