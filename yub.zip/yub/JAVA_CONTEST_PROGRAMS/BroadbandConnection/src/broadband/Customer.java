package broadband;

public class Customer 
{
	private int custId, dataUsage;
	private String custName;
	private Plan plan;
	
	public Customer(int custId, String custName, int dataUsage) 
	{
		this.custId = custId;
		this.custName = custName;
		this.dataUsage = dataUsage;
	}

	public int getCustId() {	return custId;	}

	public void setCustId(int custId) {	this.custId = custId;	}

	public int getDataUsage() {	return dataUsage;	}

	public void setDataUsage(int dataUsage) {	this.dataUsage = dataUsage;	}

	public String getCustName() {	return custName;	}

	public void setCustName(String custName) {	this.custName = custName;	}

	public Plan getPlan() {	return plan;	}

	public void setPlan(Plan plan) {	this.plan = plan;	}
	
	public int getBill()
	{
		int billAmt = 0, extra = 0;
		
		if(this.getPlan().getPlanName().equals("SUPER_LIM_10"))
		{
			if(this.getDataUsage() > 10)
				extra = (this.getDataUsage() - 10) * 25;
			
			billAmt = this.getPlan().getBaseCharge() + extra;
			
		}
		else if(this.getPlan().getPlanName().equals("SUPER_LIM_20"))
		{
			if(this.getDataUsage() > 20)
				extra = (this.getDataUsage() - 20) * 35;
			
			billAmt = this.getPlan().getBaseCharge() + extra;
		}
		else if(this.getPlan().getPlanName().equals("SUPER_UNLIM_20"))
		{
			billAmt = this.getPlan().getBaseCharge();
		}
		
		return billAmt;
	}
}
