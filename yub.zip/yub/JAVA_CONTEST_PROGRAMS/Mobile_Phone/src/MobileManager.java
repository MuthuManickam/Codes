import java.util.*;

public class MobileManager 
{
	private ArrayList<MobilePhone> phones = new ArrayList<MobilePhone>();
	
	public void addMobile(MobilePhone mp)
	{
		phones.add(mp);
	}
	
	public int allMobilesCost()
	{
		int totalCost = 0;
		
		for(int i=0; i<phones.size(); i++)
		{
			MobilePhone mm = (MobilePhone) phones.get(i);
			
			totalCost += mm.getPrice();
		}
		
		return totalCost;
	}
	
	public int mobileCost(String model)
	{
		int cost = 0;
		
		for(int i=0; i<phones.size(); i++)
		{
			MobilePhone mm = (MobilePhone) phones.get(i);
			
			if(mm.getModel().equalsIgnoreCase(model))
				cost = mm.getPrice();
		}
		
		return cost;
	}
	
	public ArrayList<SmartPhone> containsFingerPrintScanner()
	{
		ArrayList<SmartPhone> smarts = new ArrayList<SmartPhone>();
		
		for(int i=0; i<phones.size(); i++)
		{
			MobilePhone mm = (MobilePhone) phones.get(i);
			
			if(mm.getModel().startsWith("SP"))
			{
				SmartPhone ss = (SmartPhone) mm;
				
				if(ss.isHasFingerPrintScanner() == true)
					smarts.add(ss);
			}
		}
		
		return smarts;
	}
}
