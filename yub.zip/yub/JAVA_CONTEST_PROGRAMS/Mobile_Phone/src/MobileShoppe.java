import java.util.*;

public class MobileShoppe 
{
	public static void main(String args[]) throws InvalidModelException 
	{
		MobileManager mm  = new MobileManager();
		
		//FeaturePhone fp = new FeaturePhone("AB123", "OPPO", 9999);		//GENERATES EXCEPTION
		FeaturePhone fp1 = new FeaturePhone("FP101", "NOKIA", 2400);
		FeaturePhone fp2 = new FeaturePhone("FP102", "SAMSUNG", 1900);
		
		//mm.addMobile(fp);
		mm.addMobile(fp1);
		mm.addMobile(fp2);
		
		//SmartPhone sp = new SmartPhone("MN456", "APPLE", 100000, true);		//GENERATES EXCEPTION
		SmartPhone sp1 = new SmartPhone("SP501", "SAMSUNG", 23000, true);
		SmartPhone sp2 = new SmartPhone("SP502", "GOOGLE", 39000, true);
		SmartPhone sp3 = new SmartPhone("SP503", "SONY", 17000, false);
		
		//mm.addMobile(sp);
		mm.addMobile(sp1);
		mm.addMobile(sp2);
		mm.addMobile(sp3);
		
		System.out.println("TOTAL MOBILES COST : Rs."+mm.allMobilesCost());		//83300
		System.out.println("COST OF SP502 MODEL IS : Rs."+mm.mobileCost("SP502"));		//39000
		
		ArrayList<SmartPhone> sm = mm.containsFingerPrintScanner();
		System.out.println("NO. OF PHONES HAVING FINGER-PRINT READER : "+sm.size());		//2
	}
}
