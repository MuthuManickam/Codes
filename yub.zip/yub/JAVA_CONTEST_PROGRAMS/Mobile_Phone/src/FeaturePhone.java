
public class FeaturePhone extends MobilePhone
{
	public FeaturePhone(String model, String brand, int price) throws InvalidModelException
	{
		super();
		if(model.startsWith("FP"))
		{
			super.setModel(model);
			super.setBrand(brand);
			super.setPrice(price);
		}
		else
			throw new InvalidModelException("MODEL NAME SHOULD START WITH FP");
	}
}
