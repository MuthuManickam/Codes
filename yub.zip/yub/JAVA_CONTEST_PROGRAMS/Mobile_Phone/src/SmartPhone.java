
public class SmartPhone extends MobilePhone
{
	private boolean hasFingerPrintScanner;
	
	public SmartPhone(String model, String brand, int price, boolean hasFingerPrintScanner) throws InvalidModelException
	{
		super();
		if(model.startsWith("SP"))
		{
			super.setModel(model);
			super.setBrand(brand);
			super.setPrice(price);
			this.hasFingerPrintScanner = hasFingerPrintScanner;
		}
		else
			throw new InvalidModelException("MODEL NAME SHOULD START WITH SP");
	}

	public boolean isHasFingerPrintScanner() {	return hasFingerPrintScanner;	}
}
	