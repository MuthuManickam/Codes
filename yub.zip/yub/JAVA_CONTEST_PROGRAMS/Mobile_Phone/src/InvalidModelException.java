
public class InvalidModelException extends Exception
{
	InvalidModelException(String msg)
	{
		super(msg);
	}
}
