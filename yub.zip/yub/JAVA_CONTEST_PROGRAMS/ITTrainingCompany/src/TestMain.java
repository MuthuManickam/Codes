import java.io.*;
import java.util.*;
import com.beans.Requirement;
import com.exception.InvalidLevelException;
import com.train.Training;

public class TestMain 
{
	public static void main(String args[]) throws IOException, NumberFormatException, InvalidLevelException
	{
		Training t=new Training();
		
		ArrayList<Requirement> ar = t.fillList(new File("Company.txt"));
		ArrayList<Requirement> trainer = t.setTrainer();
		
		for(Requirement r:trainer)
			System.out.println(r);
		
		int x=t.courses();
		System.out.println("\nTOTAL COURSES : "+x);
		
		ArrayList<Requirement> spec=t.specific("Advanced");
		for(int i=0;i<spec.size();i++)
			System.out.println(spec.get(i));
		
		Training tr=new Training();
		ArrayList<Requirement> err=tr.fillList(new File("faulty.txt"));
	}
}
