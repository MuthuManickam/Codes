package com.exception;

public class InvalidLevelException extends Exception 
{
	public InvalidLevelException(String msg)
	{
		super(msg);
	}
}
