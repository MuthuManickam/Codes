package com.train;

import java.io.*;
import java.util.*;
import com.beans.Requirement;
import com.exception.InvalidLevelException;

public class Training 
{
	private ArrayList<Requirement> training = new ArrayList<Requirement>();
	
	public ArrayList<Requirement> fillList(File file) throws IOException, NumberFormatException, InvalidLevelException
	{
		BufferedReader br = null;
		String str = "";
		
		try
		{
			br = new BufferedReader(new FileReader(file));
			
			while((str = br.readLine()) != null)
			{
				String details[] = str.split(":");
				
				Requirement req = new Requirement(details[0], details[1], new Integer(details[2]), details[3], "");
				training.add(req);
			}
		}
		catch(IOException ioe)
		{
			System.out.println(ioe.getMessage());
		}
		br.close();
		return training;
	}
	
	public ArrayList<Requirement> setTrainer()
	{
		ArrayList<Requirement> trainers = new ArrayList<Requirement>();
				
		for(Requirement aa : training)
		{
			if(aa.getProgram().equalsIgnoreCase("Java Programming"))
				aa.setTrainer("Amit");
			if(aa.getProgram().equalsIgnoreCase("JEE Programming"))
				aa.setTrainer("Gita");
			if(aa.getProgram().equalsIgnoreCase("AngularJS"))
				aa.setTrainer("Ashwin");
			if(aa.getProgram().equalsIgnoreCase("MongoDB"))
				aa.setTrainer("Monica");
			
			trainers.add(aa);
		}
		
		return trainers;
	}
	
	public ArrayList<Requirement> specific(String level)
	{
		ArrayList<Requirement> levels = new ArrayList<Requirement>();
		
		for(Requirement rr : training)
		{
			if(rr.getLevel().equalsIgnoreCase(level))
				levels.add(rr);
		}
		
		return levels;
	}
	
	public int courses()
	{
		return training.size();
	}
	
	public ArrayList<Requirement> getTraining()	throws InvalidLevelException
	{
		ArrayList<Requirement> get = new ArrayList<Requirement>();
		
		for(Requirement rr : training)
		{
			Requirement getter = new Requirement(rr.getProgram(), rr.getLevel(), rr.getEmpCount(), rr.getDate(), rr.getTrainer());
			get.add(getter);
		}
		
		return get;
	}
	
	public void setTraining(ArrayList<Requirement> training)	throws InvalidLevelException
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("\nENTER PROGRAM NAME : ");
		String program = sc.next();
		System.out.print("\nENTER THE LEVEL : ");
		String level = sc.next();
		System.out.print("\nENTER EMPLOYEE COUNT : ");
		int empCount = sc.nextInt();
		System.out.print("\nENTER THE DATE : ");
		String date = sc.next();
		
		Requirement rr = new Requirement(program, level, empCount, date, "");
		training.add(rr);
	}
}
