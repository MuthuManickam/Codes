package com.beans;

import com.exception.InvalidLevelException;

public class Requirement 
{
	private String program, level, date, trainer;
	private int empCount;
	
	public Requirement(String program, String level, int empCount, String date, String trainer)	throws InvalidLevelException
	{
		if(level.equalsIgnoreCase("Beginner") || level.equalsIgnoreCase("Intermediate") || level.equalsIgnoreCase("Advanced"))
		{
			this.program = program;
			this.level = level;
			this.empCount = empCount;
			this.date = date;
			this.trainer = trainer;
		}
		else
			throw new InvalidLevelException("LEVEL IS INVALID, CHECK AGAIN");
	}

	public String getProgram() {	return program;	}

	public void setProgram(String program) {	this.program = program;	}

	public String getLevel() {	return level;	}

	public void setLevel(String level) {	this.level = level;	}

	public String getDate() {	return date;	}

	public void setDate(String date) {	this.date = date;	}

	public String getTrainer() {	return trainer;	}

	public void setTrainer(String trainer) {	this.trainer = trainer;	}

	public int getEmpCount() {	return empCount;	}

	public void setEmpCount(int empCount) {	this.empCount = empCount;	}
	
	
	public String toString() 
	{
		String str = "\nPROGRAM : "+this.getProgram()+"\nLEVEL : "+this.getLevel()+"\nEMPLOYEE COUNT : "+this.getEmpCount()+"\nDATE : "+this.getDate()+"\nTRAINER : "+this.getTrainer();
		return str;
	}
	
}
