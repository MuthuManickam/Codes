
public class Main 
{
	public static void main(String args[]) throws CarNotFoundException 
	{
		CarManager cm = new CarManager();
		
		SmallCar c1 = new SmallCar("OR-02-5467", "Siddharth Nanda");
		SedanCar c2 = new SedanCar("OD-54-7812", "Akash Kumar Sahoo");
		SmallCar c3 = new SmallCar("OD-54-7845", "Tiyasha Majumder");
		
		cm.addCar("OR-02-5467", c1);
		cm.addCar("OD-54-7812", c2);
		cm.addCar("OD-54-7845", c3);
		
		Car cc1 = cm.findCar("SMALL");
		System.out.print("\nCAR TYPE : "+cc1.getType());
		System.out.print("\tCAR REGN NO. : "+cc1.getRegNo());
		System.out.print("\tDRIVER NAME : "+cc1.getDriverName());
		System.out.println();
		
		Car cc2 = cm.findCar("SEDAN");
		System.out.print("\nCAR TYPE : "+cc2.getType());
		System.out.print("\tCAR REGN NO. : "+cc2.getRegNo());
		System.out.print("\tDRIVER NAME : "+cc2.getDriverName());
		System.out.println();
		
		//cm.findCar("OD-54-0000");
		
		System.out.println("\nFARE C1 : "+c1.calculateFare(15));
		System.out.println("\nFARE c2 : "+c2.calculateFare(30));
		
		
	}
}
