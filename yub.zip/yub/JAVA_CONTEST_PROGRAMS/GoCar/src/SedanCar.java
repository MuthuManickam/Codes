
public class SedanCar extends Car
{
	String regNo, type = "SEDAN", driverName;
	
	SedanCar(String regNo, String driverName)
	{
		this.regNo = regNo;
		this.driverName = driverName;
	}
	
	public float calculateFare(float kms)
	{
		return BASE_FARE + (SEDAN_CAR_FARE*kms);
	}
	
	public float getSMALL_CAR_FARE()	{	return SMALL_CAR_FARE;	}

	public void setSMALL_CAR_FARE(float SMALL_CAR_FARE)	{	this.SMALL_CAR_FARE = SMALL_CAR_FARE;	}

	public float getSEDAN_CAR_FARE() {	return SEDAN_CAR_FARE;	}

	public void setSEDAN_CAR_FARE(float SEDAN_CAR_FARE) {	this.SEDAN_CAR_FARE = SEDAN_CAR_FARE;	}

	public int getBASE_FARE() {	return BASE_FARE;	}

	public void setBASE_FARE(int BASE_FARE) {	this.BASE_FARE = BASE_FARE;	}

	public String getRegNo() {	return regNo;	}

	public void setRegNo(String regNo) {	this.regNo = regNo;	}

	public String getType() {	return type;	}

	public void setType(String type) {	this.type = type;	}

	public String getDriverName() {	return driverName;	}

	public void setDriverName(String driverName) {	this.driverName = driverName;	}
	
}
