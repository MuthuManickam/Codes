
public class CarNotFoundException extends Exception
{
	CarNotFoundException(String msg)
	{
		super(msg);
	}
}
