import java.util.*;

public class CarManager 
{
	private HashMap<String, Car> cars = new HashMap<String, Car>();
	
	/*public boolean loadCarDetails(String file)
	{
		
	}*/
	
	public void addCar(String regNo, Car car)
	{
		cars.put(regNo, car);
		System.out.println("CAR ADDEDD SUCCESSFULLY");
	}
	
	public Car findCar(String type)	throws CarNotFoundException
	{
		int flag = 0;
		Car cc = null;
		
		for(Car val : cars.values())
		{
			if(val.getType().equalsIgnoreCase(type))
			{
				cc = val;
				flag++;
				break;
			}
		}
		
		if(flag == 1)
		{
			return cc;
		}
		else
			throw new CarNotFoundException("CAR NOT FOUND");
	}	
}
