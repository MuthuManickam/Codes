package main;

import java.util.*;

public class CertificationMaster 
{
	public HashMap<String, Integer> certificationDetails = new HashMap<String, Integer>();
	
	public void addCertification(Certification c)
	{
		String certification = c.getCertCode();
		int fees = c.getFees();
		
		certificationDetails.put(certification, fees);
	}
	
	public int getCertificationFees(String certCode)	throws InvalidCertificationCode
	{
		String certificate;
		int fees = 0, flag = 0;
		
		Set certificates = certificationDetails.keySet();
		Iterator ii = certificates.iterator();
		
		while(ii.hasNext())
		{
			certificate = (String) ii.next();
			fees = certificationDetails.get(certificate);
			
			if(certCode.equals(certificate))
			{
				flag++;
				break;
			}
		}
		
		if(flag == 1)
			return fees;
		else
			throw new InvalidCertificationCode("\nINVALID CERTIFICATION CODE");
	}
	
	public void bookCertification(String certCode, Employee e)
	{
		e.getMyCertifications().add(certCode);
	}
	
	public int claimReibursement(Employee e)
	{
		String certificate;
		int fees = 0, reimbursementAmt = 0;
		
		Set certifications = certificationDetails.keySet();
		Iterator ii = certifications.iterator();
		
		while(ii.hasNext())
		{
			certificate = (String) ii.next();
			fees = certificationDetails.get(certificate);
			
			for(int i=0; i<e.getMyCertifications().size(); i++)
			{
				String cert = e.getMyCertifications().get(i);
				if(cert.equals(certificate))
					reimbursementAmt += fees;
			}
		}
		
		return reimbursementAmt;
		
	}
	
	public static void main(String args[]) throws InvalidCertificationCode, InvalidSpecialization 
	{
		Employee e1 = new Employee(1, "Debanita", "JAVA");	//SHOULD ALLOW
		//Employee e2 = new Employee(2, "Amit", "MAINFRAME");	//SHOULD THROW InvalidSpecialization
		
		Certification c1 = new Certification();
		c1.setCertCode("1Z0-148");
		c1.setFees(10000);
		
		Certification c2 = new Certification();
		c2.setCertCode("1Z0-061");
		c2.setFees(9000);
		
		Certification c3 = new Certification();
		c3.setCertCode("1Z0-803");
		c3.setFees(11000);
		
		CertificationMaster cm = new CertificationMaster();
		cm.addCertification(c1);
		cm.addCertification(c2);
		cm.addCertification(c3);
		
		System.out.println(cm.getCertificationFees("1Z0-148"));	//10000
		System.out.println(cm.getCertificationFees("1Z0-061"));	//9000
		System.out.println(cm.getCertificationFees("1Z0-803"));	//11000
		//cm.getCertificationFees("ORA-123");	//SHOULD THROW InvalidCertificationCode
		
		cm.bookCertification("1Z0-061", e1);
		System.out.println(e1.getMyCertifications().contains("1Z0-061"));	//TRUE
		cm.bookCertification("1Z0-148", e1);
		System.out.println(cm.claimReibursement(e1));	//19000
	}
}
