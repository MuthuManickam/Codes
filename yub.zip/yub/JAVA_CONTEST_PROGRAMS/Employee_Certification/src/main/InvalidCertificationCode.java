package main;

public class InvalidCertificationCode extends Exception 
{
	InvalidCertificationCode(String msg)
	{
		super(msg);
	}
}
