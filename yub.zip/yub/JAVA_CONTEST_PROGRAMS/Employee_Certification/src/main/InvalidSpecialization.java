package main;

public class InvalidSpecialization extends Exception 
{
	InvalidSpecialization(String msg)
	{
		super(msg);
	}
}
