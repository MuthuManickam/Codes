package main;

import java.util.*;

public class Employee 
{
	private int eid;
	private String eName, specialization;
	private ArrayList<String> myCertifications = new ArrayList<String>();
	
	public Employee(int eid, String eName, String specialization)	throws InvalidSpecialization
	{
		if(specialization.equals("JAVA") || specialization.equals("ORACLE"))
		{
			this.eid = eid;
			this.eName = eName;
			this.specialization = specialization;
		}
		else
			throw new InvalidSpecialization("\nSPECIALIZATION IS INVALID");
	}

	public ArrayList<String> getMyCertifications()	{	return myCertifications;	}
}
