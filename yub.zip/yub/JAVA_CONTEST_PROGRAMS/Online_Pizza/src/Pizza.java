
public abstract class Pizza 
{
	abstract float calculatePrice();
	
	public boolean validate(int size, String type)
	{
		if((type.equalsIgnoreCase("PLAIN") || type.equalsIgnoreCase("DELUXE") || type.equalsIgnoreCase("SUPREME")) && (size == 6 || size == 9 || size == 12))
			return true;
		else
			return false;
	}
}
