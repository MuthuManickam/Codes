public class NonVegPizza extends Pizza
{
	private String type;
	private int size;
	
	NonVegPizza(int size, String type)	throws InvalidPizzaException
	{
		this.size = size;
		this.type = type;
		
		if(!super.validate(this.size, this.type))
			throw new InvalidPizzaException("CHECK NON-VEG PIZZA SIZE AND/OR TYPE");
	}
	
	float calculatePrice()
	{
		float basePrice = 100*this.size;
		
		if(this.type.equalsIgnoreCase("PLAIN"))
			return basePrice;
		if(this.type.equalsIgnoreCase("DELUXE"))
			return basePrice + 150;
		if(this.type.equalsIgnoreCase("SUPREME"))
			return basePrice + 200;
		
		return 0;
	}
}