
public class VegPizza extends Pizza
{
	private String type;
	private int size;
	
	VegPizza(int size, String type)	throws InvalidPizzaException
	{
		this.size = size;
		this.type = type;
		
		if(!super.validate(this.size, this.type))
			throw new InvalidPizzaException("CHECK VEG PIZZA SIZE AND/OR TYPE");
	}
	
	float calculatePrice()
	{
		float basePrice = 50*this.size;
		
		if(this.type.equalsIgnoreCase("PLAIN"))
			return basePrice;
		if(this.type.equalsIgnoreCase("DELUXE"))
			return basePrice + 100;
		if(this.type.equalsIgnoreCase("SUPREME"))
			return basePrice + 150;
		
		return 0;
	}
}
