
public class InvalidPizzaException extends Exception
{
	InvalidPizzaException(String msg)
	{
		super(msg);
	}
}
