
public class PizzaOnline 
{
	private static float totalSales = 0;
	
	float order(Pizza pizza)
	{
		float price = pizza.calculatePrice();
		totalSales += price;
		
		return price;
	}
	
	float getTotalSales()
	{
		return totalSales;
	}
	
	public static void main(String args[]) throws InvalidPizzaException
	{
		try
		{
			PizzaOnline po = new PizzaOnline();
			
			VegPizza vp1 = new VegPizza(9, "PLAIN");
			VegPizza vp2 = new VegPizza(6, "SUPREME");
			//VegPizza vp3 = new VegPizza(12, "NORMAL");	//TO CHECK EXCEPTION
					
			NonVegPizza nvp1 = new NonVegPizza(12, "DELUXE");
			NonVegPizza nvp2 = new NonVegPizza(9, "SUPREME");
			//NonVegPizza nvp3 = new NonVegPizza(15, "DELUXE");	//TO CHECK EXCEPTION
			
			float price = po.order(vp1);
			System.out.println("VEG PIZZA COSTS : Rs."+price);
			
			price = po.order(nvp1);
			System.out.println("NON-VEG PIZZA COSTS : Rs."+price);
			
			System.out.println("TOTAL SALES DONE OF Rs."+po.getTotalSales());
		}
		catch(Exception ee)
		{
			System.out.println(ee.getMessage());
		}
	}
}
