package shop;

public class InvalidProductID extends Exception 
{
	InvalidProductID()
	{
		super();
	}
}
