package shop;

public class NotARegisteredCustomer extends Exception 
{
	NotARegisteredCustomer(String msg)
	{
		System.out.println(msg);
	}
}
