package shop;

public class Product 
{
	private String productId, productName;
	float productPrice;
	
	public Product(String productId, String productName, float productPrice)	throws InvalidProductID 
	{
		if(productId.startsWith("E") || productId.startsWith("N"))
		{
			this.productId = productId;
			this.productName = productName;
			this.productPrice = productPrice;
		}
		else
			throw new InvalidProductID();
	}

	public String getProductId() {	return productId;	}

	public void setProductId(String productId) {	this.productId = productId;	}

	public String getProductName() {	return productName;	}

	public void setProductName(String productName) {	this.productName = productName;	}

	public float getProductPrice() {	return productPrice;	}

	public void setProductPrice(float productPrice) {	this.productPrice = productPrice;	}
}
