package shop;

import java.util.*;

public class ShoppingMall 
{
	private ArrayList<Customer> custList = new ArrayList<Customer>();
	
	public void addCustomer(Customer customer)
	{
		custList.add(customer);
	}
	
	public boolean searchCustomer(Customer customer) throws NotARegisteredCustomer
	{
		boolean found = false;
		
		if(!custList.isEmpty())
		{
			for(int i=0; i<custList.size(); i++)
			{
				Customer cc = custList.get(i);
				if((cc.getCustName().equals(customer.getCustName())) && (cc.getCustId() == customer.getCustId()))
				{
					found = true;
					break;
				}
				else
					found = false;
			}
		}
		
		if(found == true)
			return found;
		else
			throw new NotARegisteredCustomer("\nCUSTOMER IS NOT REGISTERED");
	}
	
	public int getTotalCustomerCount()
	{
		return custList.size();	
	}
	
	public static void main(String args[]) 
	{
		ShoppingMall mall  = new ShoppingMall();
		mall.addCustomer(new Customer(2323, "Harish"));
		mall.addCustomer(new Customer(577, "Radha"));
		mall.addCustomer(new Customer(888, "Amit"));
		
		System.out.println("Total registered Customers are : "+mall.getTotalCustomerCount());
		
		Customer newCustomer = new Customer(577, "Radha");
		//Customer newCustomer = new Customer(346, "Shweta");	//GENERATES EXCEPTION
		
		try
		{
			if(mall.searchCustomer(newCustomer) == true)
			{
				newCustomer.shop(new Product("E101", "TV", 15000));
				newCustomer.shop(new Product("N103", "Table", 7000));
				//newCustomer.shop(new Product("S102", "Table", 7000));	//GENERATES EXCEPTION
				
				System.out.println("Total Bill = "+newCustomer.generateBill());
			}
		}
		catch(NotARegisteredCustomer e)
		{
			e.printStackTrace();
		}
		catch(InvalidProductID e)
		{
			e.printStackTrace();
		}
	}
}
