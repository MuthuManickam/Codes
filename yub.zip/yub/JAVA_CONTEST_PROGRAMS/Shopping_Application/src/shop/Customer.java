package shop;

import java.util.*;

public class Customer 
{
	private int custId;
	private String custName;
	private Vector<Product> items = new Vector<Product>();
	
	public Customer(int custId, String custName) 
	{
		this.custId = custId;
		this.custName = custName;
	}

	public int getCustId() {	return custId;	}
	
	public void setCustId(int custId) {	this.custId = custId;	}
	
	public String getCustName() {	return custName;	}
	
	public void setCustName(String custName) {	this.custName = custName;	}
	
	public boolean shop(Product selectProduct)
	{
		boolean available = false;
		
		items.add(selectProduct);
		
		if(!items.isEmpty())
		{
			for(int i=0; i<items.size(); i++)
			{
				Product pp = items.get(i);
				if((pp.getProductName().equals(selectProduct.getProductName())) && (pp.getProductId().equals(selectProduct.getProductId())))
				{
					available = true;
					break;
				}
			}
		}
		return available;
	}
	
	public float generateBill()
	{
		float amt = 0;
		
		for(int i=0; i<items.size(); i++)
		{
			Product pp = items.get(i);
			amt += pp.getProductPrice();
		}
		
		return amt;
	}
}
