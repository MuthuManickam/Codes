package main;

public class BalanceException extends Exception 
{
	BalanceException(String msg)
	{
		super(msg);
	}
}
