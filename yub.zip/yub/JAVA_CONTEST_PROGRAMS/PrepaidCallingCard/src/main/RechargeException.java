package main;

public class RechargeException extends Exception 
{
	RechargeException(String msg)
	{
		super(msg);
	}
}
