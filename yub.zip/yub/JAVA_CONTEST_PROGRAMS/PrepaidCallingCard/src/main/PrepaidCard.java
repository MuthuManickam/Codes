package main;

public class PrepaidCard implements PrepaidCalling 
{
	private int balance, minsUsed;
	
	public PrepaidCard(int balance)
	{
		this.balance = balance;
	}
	
	public int rechargeCard(int rupees)	throws RechargeException
	{
		if(rupees <= 1000)
		{
			this.balance += rupees;
			return this.balance;
		}
		else
			throw new RechargeException("\nRECHARGE AMOUNT MUST NOT EXCEED INR 1000");
	}
	
	public float useCards(int mins)	throws BalanceException
	{
		float charge = mins * PrepaidCalling.RATE;
		
		if(this.balance >= charge)
		{
			this.balance -= charge;
			this.minsUsed += mins;
			return charge;
		}
		else
			throw new BalanceException("\nNOT ENOUGH BALANCE TO MAKE THE CALL");
	}
	
	public float getBalanceAmount()
	{
		return this.balance;
	}
	
	public int getUsage()
	{
		return this.minsUsed;
	}
	
	public int getBalanceMins()
	{
		int balanceMins = (int) (this.balance/PrepaidCalling.RATE);
		
		return balanceMins;
	}
	
	public static void main(String args[]) throws BalanceException, RechargeException 
	{
		PrepaidCalling pc = new PrepaidCard(500);
		//pc.rechargeCard(1500);	//TO GENERATE EXCEPTION
		System.out.println(pc.getBalanceAmount());	//500.0
		
		pc.useCards(10);
		//pc.useCards(600);	//TO GENERATE EXCEPTION
		
		System.out.println(pc.getBalanceAmount());	//485.0
		System.out.println(pc.getUsage()); 			//10
		System.out.println(pc.getBalanceMins());	//323
		
		pc.rechargeCard(100);
		System.out.println(pc.getBalanceAmount());	//585.0
		System.out.println(pc.getBalanceMins());	//390
	}

}
