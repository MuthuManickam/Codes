
public class EmployeeNotFoundException extends Exception 
{	
	EmployeeNotFoundException(String msg)
	{
		super(msg);
	}
}
