
public class ExceptionHandling 
{
	public static void main(String args[]) 
	{
		try
		{
			try
			{
				System.out.println(1/0);	//Creates the Exception
			}
			finally
			{
				System.out.println("THE EXCEPTION IS PASSED TO OUTER CATCH BLOCK\n");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();	//Prints WHAT, WHERE and HOW the Exception occured
			System.out.println("\nEXCEPTION DUE TO : "+e.getMessage());		//Prints the cause of occured Exception
		}
		finally
		{
			System.out.println("\nEXCEPTION HANDLED SUCCESSFULLY");	//EXECUTED Irrespective of catch block execution
		}
	}
}