
public class Employee 
{
	String ename, empId;
	
	Employee()	{	}
	
	Employee(String ename, String empId)
	{
		this.ename = ename;
		this.empId = empId;
	}

	public String getEname() 
	{
		return ename;
	}

	public void setEname(String ename) 
	{
		this.ename = ename;
	}

	public String getEmpId() 
	{
		return empId;
	}

	public void setEmpId(String empId) 
	{
		this.empId = empId;
	}
}