import java.util.*;

public class TestEmployee 
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		
		ArrayList<Employee> al = new ArrayList<Employee>();
		
		Employee e1 = new Employee("Siddharth", "E001");
		Employee e2 = new Employee("Tiyasha", "E002");
		Employee e5 = new Employee("Neetu", "E003");
		Employee e3 = new Employee("Bishakha", "E004");
		Employee e4 = new Employee("Apurwa", "E005");
		
		
		al.add(e1);
		al.add(e2);
		al.add(e3);
		al.add(e4);
		al.add(e5);
		
		String name;
		System.out.print("ENTER THE NAME OF EMPLOYEE TO SEARCH : ");
		name = sc.nextLine();
		
		try
		{
			Employee ee = searchEmployee(al, name);
			if(ee != null)
			{
				System.out.println("EMPLOYEE FOUND\n");
				System.out.println("EMPLOYEE NAME : "+ee.getEname());
				System.out.println("EMPLOYEE ID : "+ee.getEmpId());
			}
			else
			{
				throw new EmployeeNotFoundException("EMPLOYEE NOT FOUND !!!");
			}
		}
		catch(EmployeeNotFoundException ee)
		{
			System.out.println(ee.getMessage());
		}
	}
	
	public static Employee searchEmployee(ArrayList aa, String name)
	{
		int flag = 0;
		Employee xx = null;
		Iterator ii = aa.iterator();
		
		System.out.println("\nSEARCHING FOR THE EMPLOYEE ...\n");
		while(ii.hasNext())
		{
			Employee ee = (Employee) ii.next();
			if(ee.getEname().equals(name))
			{
				xx = ee;
				break;
			}
		}
	
		return xx;
	}
}
