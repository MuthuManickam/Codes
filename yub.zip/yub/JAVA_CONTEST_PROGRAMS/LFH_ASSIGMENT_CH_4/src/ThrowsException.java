
public class ThrowsException 
{
	public static void main(String args[]) 
	{
		try
		{
			throw new Exception();
		}
		catch(Exception e)
		{
			System.out.println("EXCEPTION OCCURED : "+e.getMessage());
		}
		
		try
		{
			doStuff();
		}
		catch(Exception e)
		{
			System.out.println("STUFF EXCEPTION : "+e.getMessage());
		}
	}
	
	public static void doStuff() throws Exception
	{
		System.out.println("DO DTUFF");
		doMoreStuff();
		throw new Exception();
	}
	
	public static void doMoreStuff()	throws Exception	//REMOVE THIS TO GENERATE ERROR
	{
		System.out.println("DO MORE STUFF");
		throw new Exception();
	}
}
