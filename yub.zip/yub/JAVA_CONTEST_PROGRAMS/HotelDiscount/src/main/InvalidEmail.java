package main;

public class InvalidEmail extends Exception 
{
	public InvalidEmail(String msg) 
	{
		super(msg);
	}
}
