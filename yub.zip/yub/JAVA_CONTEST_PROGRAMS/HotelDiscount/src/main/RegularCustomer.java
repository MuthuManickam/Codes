package main;

public class RegularCustomer extends Customer
{
	public int billNo;
	public float grossBillAmount;

	public RegularCustomer(int custid, String custName, String email, float loyalityPoints, int billNo, float grossBillAmount)	throws InvalidEmail
	{
		super(custid, custName, email, loyalityPoints);
		this.billNo = billNo;
		this.grossBillAmount = grossBillAmount;
	}
	
	public float calculateDiscountedBill() 
	{
		float discountAmount = 0;
		discountAmount = this.grossBillAmount*0.2f;
		
		this.grossBillAmount -= discountAmount;
		return this.grossBillAmount;
	}
}
