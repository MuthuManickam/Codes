package main;

public class ExecutiveCustomer extends Customer 
{
	public int billNo;
	public float grossBillAmount;

	public ExecutiveCustomer(int custid, String custName, String email, float loyalityPoints, int billNo, float grossBillAmount)	throws InvalidEmail
	{
		super(custid, custName, email, loyalityPoints);
		this.billNo = billNo;
		this.grossBillAmount = grossBillAmount;
	}
	
	public float calculateDiscountedBill() 
	{
		float discountAmount = 0;
		if(this.loyalityPoints < 5000)
			discountAmount = this.grossBillAmount*0.3f;
		if(this.loyalityPoints >= 5000)
			discountAmount = this.grossBillAmount*0.5f;
		
		this.grossBillAmount -= discountAmount;
		return this.grossBillAmount;
	}
}
