package main;

public class Hotel
{
	private int thresholdLoyality;
	
	public Hotel(int thresholdLoyality)
	{
		this.thresholdLoyality = thresholdLoyality;
	}
	
	public float generateFinalBill(Customer c)
	{
		float billAmt = 0;
		
		if(c.loyalityPoints >= this.thresholdLoyality)
			billAmt = c.calculateDiscountedBill();
		else 
		{
			if(c instanceof ExecutiveCustomer)
				billAmt = ((ExecutiveCustomer) c).grossBillAmount;
			if(c instanceof RegularCustomer)
				billAmt = ((RegularCustomer) c).grossBillAmount;
		}
		
		return billAmt;
	}
	
	public float incrementLoyality(Customer c)
	{
		c.loyalityPoints += 10;
		
		return c.loyalityPoints;
	}
	
	public static void main(String[] args)	throws InvalidEmail
	{	
		Hotel hotel = new Hotel(100);
		
		Customer c1 = new ExecutiveCustomer(1, "Amit", "abc@gmail.com", 99, 1, 1000);
		System.out.println(hotel.generateFinalBill(c1));
		System.out.println(c1.loyalityPoints);
		System.out.println(hotel.incrementLoyality(c1));
		
		Customer c2 = new ExecutiveCustomer(1, "Amit", "abc@gmail.com", 4999, 1, 1000);
		System.out.println(hotel.generateFinalBill(c2));
		System.out.println(c2.loyalityPoints);
		System.out.println(hotel.incrementLoyality(c2));
		
		Customer c3 = new RegularCustomer(1, "Amit", "abc@gmail.com", 5001, 1, 2000);
		System.out.println(hotel.generateFinalBill(c3));
		System.out.println(c3.loyalityPoints);
		System.out.println(hotel.incrementLoyality(c3));		
		
		//Customer c4 = new ExecutiveCustomer(1, "Amit", "abc$gmail.com", 5001, 1, 2000);	//Generates Exception
	}
}
