package main;

public abstract class Customer 
{
	public int custid;
	public String custName, email;
	public float loyalityPoints;
	
	public Customer(int custid, String custName, String email, float loyalityPoints)	throws InvalidEmail
	{
		if(email.contains("@"))
		{
			this.custid = custid;
			this.custName = custName;
			this.email = email;
			this.loyalityPoints = loyalityPoints;			
		}
		else
			throw new InvalidEmail("EMAIL IS INVALID");
	}
	
	public abstract float calculateDiscountedBill();
	
	
}
