
public class DisplayThread extends Thread
{
	public void run()
	{
		System.out.println("DISPLAYING ALL CARDS ...");
		
		
		for(int i=0; i<FlashCardsData.fc.size(); i++)
		{
			FlashCard ff = FlashCardsData.fc.get(i);
			System.out.println("\nCARD : 0"+(i+1));
			System.out.println("SUBJECT : "+ff.getSubject());
			System.out.println("QUESTION : "+ff.getQuestion());
			
			try
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException ie)
			{
				System.out.println(ie.getMessage());
			}
			
			System.out.println("ANSWER : "+ff.getAnswer());
			
			try
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException ie)
			{
				System.out.println(ie.getMessage());
			}
		}
	}
}
