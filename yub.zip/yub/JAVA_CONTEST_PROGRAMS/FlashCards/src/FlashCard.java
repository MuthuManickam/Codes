
public class FlashCard extends Card
{
	private String subject, question, answer;
	
	public FlashCard(String subject, String question, String answer) 
	{
		this.subject = subject;
		this.question = question;
		this.answer = answer;
	}

	public String getSubject() {	return subject;	}

	public void setSubject(String subject) {	this.subject = subject;	}

	public String getQuestion() {	return question;	}

	public void setQuestion(String question) {	this.question = question;	}

	public String getAnswer() {	return answer;	}

	public void setAnswer(String answer) {	this.answer = answer;	}
	
	public void displayCard()
	{
		System.out.println("SUBJECT : "+this.getSubject());
		System.out.println("QUESTION : "+this.getQuestion());
		System.out.println("ANSWER : "+this.getAnswer());
	}
}
