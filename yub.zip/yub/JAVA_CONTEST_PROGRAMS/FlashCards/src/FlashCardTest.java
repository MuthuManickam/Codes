import java.util.*;

public class FlashCardTest 
{
	public static void main(String args[]) 
	{
		Scanner sc = new Scanner(System.in);
		
		FlashCardsData fcd = new FlashCardsData();
		fcd.loadData();
		
		DisplayThread dt = new DisplayThread();
		Thread tt = new Thread(dt);
		tt.run();
				
		System.out.print("\n\nENTER A SUBJECT TO SEARCH : ");
		String ss = sc.next();
		
		Card cc = fcd.searchCard(ss);
		if(cc!=null)
			((FlashCard) cc).displayCard();
	}
}
