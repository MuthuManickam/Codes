
public abstract class Card 
{
	private String subject, question, answer;
	
	

	public abstract String getSubject();

	public abstract void setSubject(String subject);

	public abstract String getQuestion();

	public abstract void setQuestion(String question);

	public abstract String getAnswer();

	public abstract void setAnswer(String answer);
}
