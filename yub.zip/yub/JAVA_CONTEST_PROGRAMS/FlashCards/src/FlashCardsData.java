import java.util.*;
import java.io.*;

public class FlashCardsData implements CardSearchable
{
	static ArrayList<FlashCard> fc = new ArrayList<FlashCard>();

	@Override
	public Card searchCard(String sub) 
	{
		int flag = 0;
		Card cc = null;
		FlashCard ff = null;
		
		for(int i=0; i<fc.size(); i++)
		{
			ff = fc.get(i);
			if(ff.getSubject().equalsIgnoreCase(sub))
			{
				flag++;
				cc = ff;
				break;
			}
		}
		
		if(flag == 1)
		{
			
			return cc;
		}
		else
		{
			System.out.println("NO SUCH SUBJECTS FOUND ...");
		}
		
		return cc;
	}
	
	public void loadData()
	{
		try 
		{
			FileReader fr = new FileReader(new File("cards_data.txt"));
			BufferedReader br = new BufferedReader(fr);
			String str;
			
			while((str = br.readLine()) != null)
			{
				String data[] = str.split(";");
				String sub = data[0];
				String ques = data[1];
				String ans = data[2];
				
				FlashCard ff = new FlashCard(sub, ques, ans);
				fc.add(ff);
			}
			
			br.close();
			fr.close();
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
		
	}
}
