
public interface CardSearchable 
{
	Card searchCard(String sub);
}
