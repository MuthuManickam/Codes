import java.io.*;

public class StoreEmployee 
{
	public static void main(String args[]) throws IOException 
	{
		Employee e1 = new Employee("E001", "Siddharth", 50000);
		Employee e2 = new Employee("E002", "Tiyasha", 45000);
		Employee e3 = new Employee("E003", "Neetu", 480000);
		
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		
		try
		{
			fos = new FileOutputStream("E:\\EmployeeStore.ser", true);
			oos = new ObjectOutputStream(fos);
			
			oos.writeBytes("\n");
			oos.writeObject(e1);
			oos.writeBytes("\n");
			oos.writeObject(e2);
			oos.writeBytes("\n");
			oos.writeObject(e3);
			
			System.out.println("OBJECT SERIALIZATION SUCCESSFULL");
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
			System.out.println(ioe.getMessage());
		}
		finally
		{
			oos.close();
			fos.close();
		}
	}
}
