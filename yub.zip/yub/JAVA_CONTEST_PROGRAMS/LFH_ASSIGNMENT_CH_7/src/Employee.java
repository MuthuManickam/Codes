import java.io.*;

public class Employee implements Serializable
{
	String empID, empName;
	int empSalary;
	
	Employee()	{	}

	public Employee(String empID, String empName, int empSalary) 
	{
		this.empID = empID;
		this.empName = empName;
		this.empSalary = empSalary;
	}
}
