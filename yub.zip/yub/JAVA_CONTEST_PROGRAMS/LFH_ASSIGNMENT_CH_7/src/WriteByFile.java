import java.io.*;

public class WriteByFile 
{
	public static void main(String args[]) throws IOException 
	{
		FileOutputStream fos = null;
		
		try
		{
			String str = "Bhubaneswar is the capital of Odisha. I love it.";
			byte[] bb = str.getBytes();
			
			File ff = new File("E:\\MyFile.txt");
			
			if(!ff.exists())
				ff.createNewFile();
			
			fos = new FileOutputStream(ff);
			fos.write(bb);
		}
		catch(IOException ioe)
		{
			System.out.println(ioe.getMessage());
		}
		finally
		{
			if(fos != null)
				fos.close();
		}
	}
}
