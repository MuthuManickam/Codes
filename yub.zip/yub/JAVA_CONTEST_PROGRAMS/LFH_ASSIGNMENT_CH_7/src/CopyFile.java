import java.io.*;

public class CopyFile 
{
	public static void main(String args[]) 
	{
		try
		{
			
			File f1 = new File("E:\\Java_Program\\file\\file1.txt");
			File f2 = new File("E:\\Java_Program\\file\\file2.txt");
			
			FileInputStream fi = new FileInputStream(f1);
			FileOutputStream fo = new FileOutputStream(f2, true);
			
			char[] cc = new char[25];
			int ch;
				
			while((ch=fi.read()) != -1)
			{
				fo.write(ch);
			}
			
			System.out.println("COPIED SUCCESSFULLY");
			
			File ff = new File("E:\\Java_Program\\file\\file2.txt");
			FileInputStream fis = new FileInputStream(ff);
			
			while(fis.available() > 0)
			{
				System.out.print((char)fis.read());
			}
		}
		catch(IOException ioe)
		{
			System.out.println(ioe.getMessage());
		}
		
		
		
	}
}
