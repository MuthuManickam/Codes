import java.io.*;

public class CreateDirectory 
{
	public static void main(String args[]) 
	{
		String fname = "MyFile";
		
		File ff = new File(fname);
		
		try
		{
			ff.mkdir();
		}
		catch(Exception ee)
		{
			System.out.println(ee.getMessage());
		}
		
		System.out.println(ff.exists());
		System.out.println("DIRECTORY CREATED");
	}
}
