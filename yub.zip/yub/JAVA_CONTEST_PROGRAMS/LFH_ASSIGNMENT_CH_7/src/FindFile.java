import java.io.*;
import java.util.*;

public class FindFile 
{
	public static void main(String args[]) 
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.print("ENTER FILE NAME WITH EXTENSION : ");
		String fname = sc.next();
		
		File ff = new File(fname);
		
		if(!ff.exists())
			System.out.println("FILE FOUND");
		else
			System.out.println("4O4 FILE NOT FOUND");
	}
}
