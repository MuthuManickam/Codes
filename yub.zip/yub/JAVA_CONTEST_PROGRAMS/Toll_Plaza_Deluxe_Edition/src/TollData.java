
public class TollData 
{
	private int privateCount = 0, commercialCount = 0;
	private float privateAmount = 0, commercialAmount = 0;
	
	public float makeEntry(Vehicle v, String road, String type) throws RoadException
	{
		float tax = 0;
		
		if(v instanceof PrivateVehicle)
		{
			PrivateVehicle pv = (PrivateVehicle) v;
			
			privateCount++;
			tax = pv.calcTax(road, type);
			privateAmount += tax;
		}
		
		if(v instanceof CommercialVehicle)
		{
			CommercialVehicle cv = (CommercialVehicle) v;
			
			commercialCount++;
			tax = cv.calcTax(road, type);
			commercialAmount += tax;
		}
		
		return tax;
	}
	
	public int getPrivateCount()	{	return this.privateCount;	}
	
	public float getPrivateAmount()	{	return this.privateAmount;	}
	
	public int getCommercialCount()	{	return this.commercialCount;	}
	
	public float getCommercialAmount()	{	return this.commercialAmount;	}
	
	public static void main(String args[]) throws RoadException 
	{
		PrivateVehicle pv=new PrivateVehicle("MH01C1111");
		CommercialVehicle cv=new CommercialVehicle("MH01C2222");
		TollData td=new TollData();

		float pvtax= td.makeEntry(pv,"NATIONAL","SINGLE");
		System.out.println(pvtax);
		
		float cvtax= td.makeEntry(cv,"NATIONAL","RETURN");
		System.out.println(cvtax);
		
		System.out.println("PC : "+td.getPrivateCount()+"\nPA : "+td.getPrivateAmount()+"\nCC : "+td.getCommercialCount()+"\nCA : "+ td.getCommercialAmount());

	}
}
