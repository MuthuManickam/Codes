
public class RoadException extends Exception 
{
	RoadException(String msg)
	{
		super(msg);
	}
}