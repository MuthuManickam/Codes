
public class PrivateVehicle extends Vehicle
{
	public PrivateVehicle(String regdNo) 
	{
		super(regdNo);
	}

	public float calcTax(String road, String journey) throws RoadException
	{
		float tax = 0;
		
		if(journey.equalsIgnoreCase("SINGLE") || journey.equalsIgnoreCase("RETURN"))
		{
			if(road.equalsIgnoreCase("NATIONAL"))
				tax = 150;
			else if(road.equalsIgnoreCase("STATE"))
				tax = 100;
			else if(road.equalsIgnoreCase("LOCAL"))
				tax = 50;
			else 
				throw new RoadException("INVALID HIGHWAY");
			
			if(journey.equalsIgnoreCase("RETURN"))
				tax += tax*0.5;
		}
		else 
			throw new RoadException("INVALID JOURNEY TYPE");
		
		return tax;
	}
}
