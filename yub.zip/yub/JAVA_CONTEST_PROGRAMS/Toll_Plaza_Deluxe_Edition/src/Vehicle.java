
public abstract class Vehicle 
{
	private String regdNo;
	
	public Vehicle(String regdNo)
	{
		this.regdNo = regdNo;
	}
	
	public String getRegdNo()
	{
		return this.regdNo;
	}
	
	public abstract float calcTax(String road, String journey)	throws RoadException;
}
