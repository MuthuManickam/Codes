
public class HelloThread extends Thread
{
	HelloThread()	{	}
	
	public void run()
	{
		System.out.println("HELLO WORLD !");
	}
}
