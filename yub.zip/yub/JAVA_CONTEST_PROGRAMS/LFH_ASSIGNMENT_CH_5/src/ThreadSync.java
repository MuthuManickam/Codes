
public class ThreadSync implements Runnable
{
	ThreadSync()	{	}
	
	public synchronized void run()
	{
		System.out.println(Thread.currentThread().getName()+" RUNNING");
		try
		{
			Thread.sleep(1000);
		}
		catch(InterruptedException ie)
		{
			System.out.println(ie.getMessage());
		}
	}
	
	public static void main(String args[]) 
	{
		ThreadSync ts = new ThreadSync();

		Thread t1 = new Thread(ts);
		Thread t2 = new Thread(ts);
		Thread t3 = new Thread(ts);
		
		t1.setName("THREAD 1");
		t2.setName("THREAD 2");
		t3.setName("THREAD 3");
		
		t1.start();
		t2.start();
		t3.start();
	}
}
