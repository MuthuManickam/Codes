
public class RunnableThread implements Runnable
{
	RunnableThread()	{	}
	
	public void run()
	{
		System.out.println("RUN METHOD OVERRIDEN");
	}
}
