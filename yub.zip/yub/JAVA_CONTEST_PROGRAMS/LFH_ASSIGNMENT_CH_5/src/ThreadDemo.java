
public class ThreadDemo 
{
	public static void main(String args[]) 
	{
		HelloThread ht = new HelloThread();
		Thread tt = new Thread(ht);
		
		tt.start();
	}
}
