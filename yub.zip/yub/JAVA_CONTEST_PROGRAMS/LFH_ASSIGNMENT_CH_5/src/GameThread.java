
public class GameThread extends Thread
{
	String threadName;
	
	GameThread()	{	}
	
	GameThread(String threadName)
	{
		this.threadName = threadName;
	}
	
	public void run()
	{
		System.out.println("THREAD "+this.threadName+" RUNNING");
	}
}
