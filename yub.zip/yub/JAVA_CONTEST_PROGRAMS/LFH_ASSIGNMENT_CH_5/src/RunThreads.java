
public class RunThreads 
{	
	public static void main(String args[]) 
	{
		PrintedNumbersThread p1 = new PrintedNumbersThread("1");
		PrintedNumbersThread p2 = new PrintedNumbersThread("2");
		
		p1.start();
		p2.start();
	}
}
