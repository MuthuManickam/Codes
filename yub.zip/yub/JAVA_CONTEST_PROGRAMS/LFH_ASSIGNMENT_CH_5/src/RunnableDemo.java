
public class RunnableDemo 
{
	public static void main(String args[]) 
	{
		RunnableThread rt = new RunnableThread();
		Thread tt = new Thread(rt);
		
		tt.start();
	}
}
