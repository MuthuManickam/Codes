
public class PrintedNumbersThread extends Thread 
{
	String name;
	
	PrintedNumbersThread()	{	}
	
	PrintedNumbersThread(String name)
	{
		this.name = name;
	}
	
	public void run()
	{
		try
		{
			for(int i=1; i<=10; i++)
			{
				System.out.println("THREAD"+this.name+" : "+i);
				Thread.sleep(500);
			}
		}
		catch(InterruptedException ie)
		{
			System.out.println(ie.getMessage());
		}
	}
}
