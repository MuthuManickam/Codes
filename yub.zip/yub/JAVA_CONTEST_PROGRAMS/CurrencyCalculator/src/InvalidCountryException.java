
public class InvalidCountryException extends Exception 
{
	InvalidCountryException(String msg)
	{
		super(msg);
	}
}
