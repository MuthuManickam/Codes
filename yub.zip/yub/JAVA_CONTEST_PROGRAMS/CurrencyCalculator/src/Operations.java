import java.util.*;

public class Operations 
{
	private int amountInRupees;
	private ArrayList<Currency> currency = new ArrayList<Currency>();
	
	public int getAmountInRupees() {	return amountInRupees;	}
	
	public void addToList(Currency c)
	{
		currency.add(c);
	}
	
	public float convertToRupee(String country, int amountInRupees)	throws InvalidCountryException
	{
		CountryValidator cv = new CountryValidator();
		if(cv.validateCountry(country))
		{
			double exchangeRate = 0; 
			
			for(int i=0; i<currency.size(); i++)
			{
				Currency cc = currency.get(i);
				if(cc.getCountryName().equalsIgnoreCase(country))
				{
					exchangeRate = cc.getRateInRupee();
					break;
				}
			}
			
			float amount = (float) (amountInRupees * exchangeRate);
			
			return amount;
		}
		else
			throw new InvalidCountryException("COUNTRY IS INVALID");
	}
	
	public String getCurrencyByCountryName(String country)
	{
		CountryValidator cv = new CountryValidator();
		String currencyName = null;
		if(cv.validateCountry(country))
		{			
			for(int i=0; i<currency.size(); i++)
			{
				Currency cc = currency.get(i);
				if(cc.getCountryName().equalsIgnoreCase(country))
				{
					currencyName = cc.getCurrencyName();
					break;
				}
			}
		}
		
		return currencyName;
	}
	
	public float getMinValue()
	{
		int size = currency.size();
		ArrayList<Float> rates = new ArrayList<Float>();
		
		for(int i=0; i<size; i++)
		{
			Currency cc = currency.get(i);
			rates.add(cc.getRateInRupee());
		}
		
		Collections.sort(rates);
		
		return rates.get(0);
	}
}
