
public class CountryValidator 
{
	public static String[] countries = {"US", "UK", "Europe", "Singapore", "Japan"};
	
	public boolean validateCountry(String country)
	{
		int flag = 0;
		
		for(int i=0; i<countries.length; i++)
		{
			if(countries[i].equalsIgnoreCase(country))
			{
				flag++;
				break;
			}
		}
		
		if(flag == 1)
			return true;
		else
			return false;
	}
}
