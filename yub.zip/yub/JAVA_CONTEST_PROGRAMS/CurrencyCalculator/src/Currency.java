
public class Currency 
{
	private String countryName, currencyName;
	private float rateInRupee;
	
	public Currency(String countryName, String currencyName, float rateInRupee)	throws InvalidCountryException
	{
		CountryValidator cv = new CountryValidator();
		if(cv.validateCountry(countryName))
		{
			this.countryName = countryName;
			this.currencyName = currencyName;
			this.rateInRupee = rateInRupee;
		}
		else
			throw new InvalidCountryException("COUNTRY IS INVALID");
	}

	public String getCountryName() {	return countryName;	}

	public void setCountryName(String countryName) {	this.countryName = countryName;	}

	public String getCurrencyName() {	return currencyName;	}

	public void setCurrencyName(String currencyName) {	this.currencyName = currencyName;	}

	public float getRateInRupee() {	return rateInRupee;	}

	public void setRateInRupee(float rateInRupee) {	this.rateInRupee = rateInRupee;	}		
}
