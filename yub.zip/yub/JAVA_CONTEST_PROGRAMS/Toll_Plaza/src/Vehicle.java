
public abstract class Vehicle 
{
	String regNo;				//Vehicle Registration No
	
	Vehicle(String regNo)		//Base Class Constructor
	{	
		this.regNo = regNo;	
	}
	
	abstract float calcTax(String type, String highway)throws RoadException;
	
	public String getRegNo()
	{
		return regNo;
	}
}
