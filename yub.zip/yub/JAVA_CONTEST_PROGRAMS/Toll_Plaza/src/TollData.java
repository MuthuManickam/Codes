public class TollData 
{		
	int totalPrivateTax = 0, totalCommercialTax = 0, totalPrivateCount = 0, totalCommercialCount = 0;
	
	public static void main(String args[]) throws RoadException 
	{
		PrivateVehicle pv = new PrivateVehicle("TS07EA1149");
		CommercialVehicle cv = new CommercialVehicle("TS07EA1148");
		PrivateVehicle p1 = new PrivateVehicle("OD-O2-5448");
		
		TollData td = new TollData();		
		
		td.makeEntry(pv, "PRIVATE", "NATIONAL");
		td.makeEntry(cv, "COMMERCIAL", "LOCAL");
		td.makeEntry(p1, "Commercial", "Local");
		
		System.out.println("TOTAL PRIVATE COUNT IS : "+td.getTotalPrivateCount());
		System.out.println("TOTAL COMMERCIAL COUNT IS : "+td.getTotalCommercialCount());
		System.out.println("TOTAL PRIVATE TAX : "+td.getTotalPrivateTax());
		System.out.println("TOTAL COMMERCIAL TAX : "+td.getTotalCommercialTax());
	}
	
	float makeEntry(Vehicle v, String type, String highway) throws RoadException
	{
		float tax = 0;
		if(type.equalsIgnoreCase("PRIVATE"))
		{
			totalPrivateCount++;
			tax = v.calcTax(type, highway);
			totalPrivateTax += tax;
		}
		else if(type.equalsIgnoreCase("COMMERCIAL"))
		{
			totalCommercialCount++;
			tax = v.calcTax(type, highway);
			totalCommercialTax += tax;
		}
		else throw new RoadException("INVALID VEHICLE TYPE");
		
		return tax;
	}
	
	public int getTotalPrivateCount()
	{
		return totalPrivateCount;
	}	
	
	public int getTotalCommercialCount()
	{
		return totalCommercialCount;
	}
	
	public float getTotalPrivateTax()
	{
		return totalPrivateTax;
	}
	
	public float getTotalCommercialTax()
	{
		return totalCommercialTax;
	}
	
}
