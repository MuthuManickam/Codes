
public class RoadException extends Exception
{
	public RoadException(String msg)
	{
		super(msg);
	}
}
