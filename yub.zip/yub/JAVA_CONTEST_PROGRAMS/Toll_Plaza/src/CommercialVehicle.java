
public class CommercialVehicle extends Vehicle 
{
	CommercialVehicle(String regNo)		//Base Class Constructor
	{
		super(regNo);
	}
	
	float calcTax(String type, String highway) throws RoadException
	{
		float tax = 0;
		
		if(highway.equalsIgnoreCase("NATIONAL"))
			tax = 150;
		else if(highway.equalsIgnoreCase("STATE"))
			tax = 100;
		else if(highway.equalsIgnoreCase("LOCAL"))
			tax = 50;
		else throw new RoadException("INVALID HIGHWAY");
		
		return tax;
	}
}