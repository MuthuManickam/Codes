package main;

public class BusPass extends VehiclePass
{
	public BusPass(String routeNo, int kms)
	{
		if(isValidBusRoute(routeNo))
		{
			this.setRouteNumber(routeNo);
			this.setTotalKms(kms);
			
			if(kms > 0  && kms <= 20)
				this.setRouteType("Short");
			else if(kms > 20)
				this.setRouteType("Long");
		}
		else
			throw new InvalidRouteNumberException("\nBUS ROUTE NUMBER IS INVALID\n");
	}
	
	public boolean isValidBusRoute(String routeNo)
	{
		if(routeNo.startsWith("B") && routeNo.length() == 4)
			return true;
		else
			return false;
	}
	
	public int calculateFare()
	{
		int totalFare = 0;
		
		if(this.getRouteType().equalsIgnoreCase("Short"))
			totalFare = this.getTotalKms()*50;
		else if(this.getRouteType().equalsIgnoreCase("Long"))
			totalFare = 1000 + (this.getTotalKms()-20)*25;	//1000 = 50 x 20 (FIXED FOR LONG DISTANCE)
		
		return totalFare;
	}
}
