package main;

public class CabPass extends VehiclePass
{
	public CabPass(String routeNo, int kms)
	{
		if(isValidCabRoute(routeNo))
		{
			this.setRouteNumber(routeNo);
			this.setTotalKms(kms);		
			
			if(kms > 0  && kms <= 20)
				this.setRouteType("Short");
			else if(kms > 20)
				this.setRouteType("Long");
		}
		else
			throw new InvalidRouteNumberException("\nCAB ROUTE NUMBER IS INVALID\n");
	}
	
	public boolean isValidCabRoute(String routeNo)
	{
		if(routeNo.startsWith("C") && routeNo.length() == 4)
			return true;
		else
			return false;
	}
	
	public int calculateFare()
	{
		int totalFare = 0;
		
		if(this.getRouteType().equalsIgnoreCase("Short"))
			totalFare = this.getTotalKms()*80;
		else if(this.getRouteType().equalsIgnoreCase("Long"))
			totalFare = 1600 + (this.getTotalKms()-20)*50;	//1000 = 80 x 20 (FIXED FOR LONG DISTANCE)
		
		return totalFare;
	}
}
