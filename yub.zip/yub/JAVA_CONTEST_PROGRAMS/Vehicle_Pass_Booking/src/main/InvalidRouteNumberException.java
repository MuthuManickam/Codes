package main;

public class InvalidRouteNumberException extends RuntimeException
{
	
	InvalidRouteNumberException(String msg)
	{
		super(msg);
	}
}
