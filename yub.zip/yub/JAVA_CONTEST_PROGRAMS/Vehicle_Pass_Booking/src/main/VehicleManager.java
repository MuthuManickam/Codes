	package main;

import java.util.*;

public class VehicleManager 
{
	private ArrayList<VehiclePass> passes = new ArrayList<VehiclePass>();
	
	public void addPass(VehiclePass vp)
	{
		passes.add(vp);
	}
	
	public int getBusPassCount()
	{
		int count = 0;
		
		for(int i=0; i<passes.size(); i++)
		{
			VehiclePass vv = (VehiclePass) passes.get(i);
			
			if(vv.getRouteNumber().startsWith("B"))
				count++;
		}
		
		return count;
	}
	
	public int getCabPassCount()
	{
		int count = 0;
		
		for(int i=0; i<passes.size(); i++)
		{
			VehiclePass vv = (VehiclePass) passes.get(i);
			
			if(vv.getRouteNumber().startsWith("C"))
				count++;
		}
		
		return count;
	}
}
