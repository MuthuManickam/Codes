package main;

public class TransportMain 
{
	public static void main(String args[]) throws InvalidRouteNumberException 
	{
		VehicleManager vm  = new VehicleManager();
		
		BusPass b = new BusPass("B101", 15);
		System.out.println(b.calculateFare());	//750
		vm.addPass(b);
		
		BusPass b1 = new BusPass("B102", 22);
		System.out.println(b1.calculateFare());	//1050
		vm.addPass(b1);
		
		System.out.println("BUS PASSES ISSUED : "+vm.getBusPassCount());	//2
		
		CabPass c = new CabPass("C101", 15);
		System.out.println(c.calculateFare());	//1200
		vm.addPass(c);
		
		CabPass c2 = new CabPass("C102", 18);
		System.out.println(c2.calculateFare());	//1440
		vm.addPass(c2);
		
		CabPass c3 = new CabPass("C103", 22);
		System.out.println(c3.calculateFare());	//1700
		vm.addPass(c3);
		
		System.out.println("CAB PASSES ISSUED : "+vm.getCabPassCount());	//3
	}
}
