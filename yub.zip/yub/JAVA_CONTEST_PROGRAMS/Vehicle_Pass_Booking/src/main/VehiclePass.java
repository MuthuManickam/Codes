package main;

public abstract class VehiclePass 
{
	private String routeType, routeNumber;
	private int totalKms;
	
	public String getRouteType() {	return routeType;	}
	
	public void setRouteType(String routeType) {	this.routeType = routeType;	}
	
	public String getRouteNumber() {	return routeNumber;	}
	
	public void setRouteNumber(String routeNumber) {	this.routeNumber = routeNumber;	}
	
	public int getTotalKms() {	return totalKms;	}
	
	public void setTotalKms(int totalKms) {	this.totalKms = totalKms;	}
	
	public abstract int calculateFare();
}
