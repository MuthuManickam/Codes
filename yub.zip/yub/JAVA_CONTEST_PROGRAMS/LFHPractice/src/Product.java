public class Product 
{
	String productId, productName, productType;
	double productPrice;
	
	Product()	{	}
	
	Product(String productId, String productName, String productType, double productPrice)
	{
		this.productId = productId;
		this.productName = productName;
		this.productType = productType;
		this.productPrice = productPrice;
	}
	
	public String getProductId()	{	return productId;	}

	public void setProductId(String productId)	{	this.productId = productId;	}

	public String getProductName()	{	return productName;	}

	public void setProductName(String productName)	{	this.productName = productName;	}

	public String getProductType()	{	return productType;	}

	public void setProductType(String productType)	{	this.productType = productType;	}

	public double getProductPrice()	{	return productPrice;	}

	public void setProductPrice(double productPrice)	{	this.productPrice = productPrice;	}
	
	public String toString()
	{
		String str = "PRODT ID : "+this.productId+"\nPRODUCT NAME : "+this.productName+"\nPRODUCT TYPE : "+this.productType+"\nPRODUCT PRICE : Rs. "+this.productPrice+"\n";
		
		return str;
	}
}

class ProductTest
{
	public static void main(String args[]) 
	{
		Product p1 = new Product();
		System.out.println(p1);
		p1.setProductId("P001");
		p1.setProductName("i7 7700K");
		p1.setProductType("CPU");
		p1.setProductPrice(23450.99);
		System.out.println(p1);
		
		Product p2 = new Product("P002", "GTX 1080Ti", "GPU", 65499.99);
		System.out.println(p2);
	}
}