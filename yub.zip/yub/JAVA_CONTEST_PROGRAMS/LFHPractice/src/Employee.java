
public class Employee 
{
	String empNo, eName;
	double salary;
	
	Employee()	{	}
	
	Employee(String empNo, String eName, double salary)
	{
		this.empNo = empNo;
		this.eName = eName;
		this.salary = salary;
	}
	
	void display()
	{
		System.out.println("EMLOYEE NO : "+this.empNo);
		System.out.println("EMPLOYEE NAME : "+this.eName);
		System.out.println("EMPLOYEE SALARY : Rs. "+salary);
	}
	
	public static void main(String args[]) 
	{
		Employee ee = new Employee("E0001", "Siddharth Nanda", 260000.00);
		ee.display();	
	}
}