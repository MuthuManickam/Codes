
class Add 
{
	int x, y;

	public Add() {	}
	
	public Add(int x, int y) 
	{
		this();
		this.x = x;
		this.y = y;
	}
	
	public int addInt()
	{
		return this.x+this.y;
	}

	public String toString()
	{
		return x+" + "+y+" = "+(x+y);
	}
}
public class Demo
{	
	public static void main(String args[]) 
	{
		Add aa = new Add(4,87);
		System.out.println(aa.toString());
		System.out.println("SUM : "+aa.addInt());
	}
	
}