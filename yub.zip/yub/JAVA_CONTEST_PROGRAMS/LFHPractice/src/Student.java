
public class Student 
{
	int rollNo;
	String sName, course;
	static String instituteName = "ITER";
	
	Student()	{	}
	
	Student(int rollNo, String sName, String course)
	{
		this.rollNo = rollNo;
		this.sName = sName;
		this.course = course;
	}
	
	void display()
	{
		System.out.println("ROLL NO : "+this.rollNo);
		System.out.println("STUDENT's NAME : "+this.sName);
		System.out.println("COURSE : "+this.course);
		System.out.println("INSTITUTE NAME : "+instituteName);
	}
	
	public static void main(String args[]) 
	{
		Student ss = new Student(101, "Siddharth Nanda", "B. Tech.");
		ss.display();
		
		System.out.println("INSTITUTE NAME : "+instituteName);
	}
}