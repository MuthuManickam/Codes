
public class MissingNumber 
{
	public static void main(String args[]) 
	{
		int[] arr = {3, 2, 1, 7, 5, 4};
		
		int missingNumber = MissingNumber(arr);
		System.out.println(missingNumber);
	}
	
	public static int MissingNumber(int[] arr)
	{
		int sum = 0, n = arr.length+1;
		for(int i=0; i<arr.length; i++)
			sum += arr[i];
		
		int miss = (n*(n+1))/2 - sum;
		
		return miss;
	}
}
