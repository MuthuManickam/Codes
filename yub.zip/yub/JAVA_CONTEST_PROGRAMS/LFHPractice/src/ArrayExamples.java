
public class ArrayExamples 
{
	public static void main(String args[]) 
	{
		int[] arr = {1,2,3,4,5};
		int sum = 0;
		
		for(int i=0; i<arr.length; i++)
		{
			sum += arr[i];
		}
		System.out.println("SUM OF ALL ELEMENTS : "+sum);	//SUM OF ALL ELEMENTS
		
		System.out.println("ELEMENTS AT EVEN POSITION : ");
		for(int i=0; i<arr.length; i=i+2)
		{
			System.out.print(arr[i]+"\t");		//ELEMENTS AT EVEN POSITION
		}
		
		System.out.println("\nELEMENTS AT ODD POSITION : ");
				for(int i=1; i<arr.length; i=i+2)
		{
				System.out.print(arr[i]+"\t");	//ELEMENTS AT ODD POSITION
		}
		
		System.out.println("\nELEMENTS IN REVERSE ORDER : ");
		for(int i=arr.length-1; i>=0; i--)
		{
			System.out.print(arr[i]+"\t");		//ELEMENTS IN REVERSE ORDER
		}
	}
}
