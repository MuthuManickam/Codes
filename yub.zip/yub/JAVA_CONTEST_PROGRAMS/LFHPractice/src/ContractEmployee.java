
public class ContractEmployee extends Employee 
{
	String duration;
	
	ContractEmployee(String empId, String eName, double salary, String duration)
	{
		super(empId, eName, salary);
		this.duration = duration;
	}
	
	void display()
	{
		super.display();
		System.out.println("DURATION : "+this.duration);
	}
	
	public static void main(String args[]) 
	{
		ContractEmployee ce = new ContractEmployee("E0001", "Siddharth Nanda", 260000.00, "2 Years");
		ce.display();	
	}
}