import java.util.*;

public class EvenOddArray 
{
	public static void main(String args[]) 
	{
		int[] arr = {14, 24, 63, 264, 327, 585, 1, 3, 572, 896};
		
		int[] evenOdd = ReArrangeArrayElements(arr, arr.length);
		
		for(int i=0; i<evenOdd.length; i++)
			System.out.print(evenOdd[i]+" ");
	}
	
	public static int[] ReArrangeArrayElements(int[] arr, int length)
	{		
		int e = 0, o = 0, j = 0;
		
		int[] even = new int[length];
		int[] odd = new int[length];
		
		for(int i=0; i<length; i++)
		{
			if(arr[i] % 2 == 0)
			{
				even[e] = arr[i];
				e++;
			}
			else
			{
				odd[o] = arr[i];
				o++;
			}
		}
	
		int[] evenOdd = new int[length];
		
		for(int i=0; i<(e+o)/2; i++)
		{
			evenOdd[2*i+0] = even[i];
			evenOdd[2*i+1] = odd[i];
		}
		
		return evenOdd;
	}
}
