public class StringExamples 
{
	public static void main(String args[]) 
	{
		String s1 = args[0].toString();
		String s2 = args[1].toString();
		String s3 = s1.concat(s2);
		
		System.out.println("LENGTH OF FIRST STRING : "+s1.length()+"\nLENGTH OF SECOND STRING : "+s2.length());
		System.out.println("SUBSTRING OS STRING IS : "+s1.substring(3, 6)+", "+s2.substring(1, 4));
		System.out.println("THE CONCATANATED STRING IS : "+s3+"\nLENGTH OF CONCATANATED STRING IS : "+s3.length());
		System.out.println("UPPERCASE : "+s1.toUpperCase()+", "+s2.toUpperCase());
		System.out.println("LOWERCASE : "+s1.toLowerCase()+", "+s2.toLowerCase());
	}
}
