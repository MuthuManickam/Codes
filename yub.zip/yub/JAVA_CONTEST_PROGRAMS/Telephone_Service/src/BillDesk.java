
public class BillDesk implements ProcessBill
{
	private int grossBillProcessed;
	
	public int calculateBill(Customer c)
	{
		int grossBillAmount = 0;
		
		for(int i=0; i<c.getMyBills().size(); i++)
		{
			Bill bb = (Bill) c.getMyBills().get(i);
			int totalCall = bb.getCallDuration();
			int totalSms = bb.getSmsCount();
			
			int chargeCall = totalCall * 1;
			double chargeSms = totalSms * 0.5;
			
			grossBillAmount += (int) (chargeCall + chargeSms);
			grossBillProcessed++;
		}
		
		return grossBillAmount;
	}
	
	public int calculateDiscount(String type, int amount)
	{
		int discount = 0;
		if(type.equalsIgnoreCase("Executive"))
		{
			discount = (int) (amount * 0.1);
		}
		
		return discount;
	}

	public int getGrossBillProcessed() {	return grossBillProcessed;	}
}
