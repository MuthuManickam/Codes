
public class InvalidPhoneNumberException extends Exception 
{
	InvalidPhoneNumberException(String msg)
	{
		super(msg);
	}
}
