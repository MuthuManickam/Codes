
public class Bill 
{
	private String phoneNumber;
	private int callDuration, smsCount;
	
	Bill(String phoneNumber, int callDuration, int smsCount) throws InvalidPhoneNumberException
	{
		int flag = 0;
		if(phoneNumber.length() == 10)
		{
			for(int i=0; i<phoneNumber.length(); i++)
			{
				if(!Character.isDigit(phoneNumber.charAt(i)))
				{
					flag++;
					break;
				}
					
			}
			if(flag == 0)
			{
				this.phoneNumber = phoneNumber;
				this.callDuration = callDuration;
				this.smsCount = smsCount;
			}
			else
				throw new InvalidPhoneNumberException("\nPHONE NUMBER SHOULD CONTAIN ONLY DIGITS\n");
		}
		else
			throw new InvalidPhoneNumberException("\nPHONE NUMBER SHOULD CONTAIN 10 DIGITS\n");
	}

	public String getPhoneNumber() {	return phoneNumber;	}

	public void setPhoneNumber(String phoneNumber) {	this.phoneNumber = phoneNumber;	}

	public int getCallDuration() {	return callDuration;	}

	public void setCallDuration(int callDuration) {	this.callDuration = callDuration;	}

	public int getSmsCount() {	return smsCount;	}

	public void setSmsCount(int smsCount) {	this.smsCount = smsCount;	}
}
