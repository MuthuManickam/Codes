
public interface ProcessBill 
{
	int calculateBill(Customer c);
	
	int calculateDiscount(String type, int amount);
}
