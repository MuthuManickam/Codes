import java.util.*;

public class Customer 
{
	private String name, type;
	private ArrayList<Bill> myBills = new ArrayList<Bill>();
	
	Customer(String name, String type)
	{
		if(type.equalsIgnoreCase("Standard") || type.equalsIgnoreCase("Executive"))
		{
			this.name = name;
			this.type = type;
		}
	}
	
	public void addBill(Bill b)
	{
		myBills.add(b);
	}
	
	public int billCount()
	{
		return myBills.size();
	}

	public String getName() {	return name;	}

	public String getType() {	return type;	}

	public ArrayList<Bill> getMyBills() {	return myBills;	}
}
