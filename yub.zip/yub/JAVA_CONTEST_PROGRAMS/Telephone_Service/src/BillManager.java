
public class BillManager 
{
	public static void main(String args[]) throws InvalidPhoneNumberException 
	{
			
		//Bill b = new Bill("989898", 10, 50);	//GENERATES EXCEPTION
		
		Customer c = new Customer("Amit", "Executive");
		
		Bill b1 = new Bill("9876543210", 15000, 75);		//15037
		Bill b2 = new Bill("1234567890", 20000, 50);		//20025
		
		c.addBill(b1);
		c.addBill(b2);
		
		System.out.println("TOTAL BILL COUNT : "+c.billCount());		//2
		
		BillDesk bd = new BillDesk();
		
		int totalBill = bd.calculateBill(c);
		
		System.out.println("TOTAL BILL AMOUNT : Rs."+totalBill);		//35062
		System.out.println("TOTAL DISCOUNT IS : Rs."+bd.calculateDiscount(c.getType(), totalBill));		//3506
		System.out.println("TOTAL BILL PROCESSED : "+bd.getGrossBillProcessed());		//2
	}
}
