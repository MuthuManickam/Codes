package main;

public class InvalidAccountNumber extends Exception
{
	InvalidAccountNumber(String msg)
	{
		super(msg);
	}
}
