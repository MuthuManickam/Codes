package main;

public class Account 
{
	private String accountNumber, customerName;
	private float totalBalance = 0;
	private boolean isSalaryAccount = false;
	
	public Account(String accountNumber, String customerName, boolean isSalaryAccount)	throws InvalidAccountNumber
	{
		if(accountNumber.startsWith("SAL") || accountNumber.startsWith("GEN"))
		{
			this.accountNumber = accountNumber;
			this.customerName = customerName;
			this.isSalaryAccount = isSalaryAccount;
		}
		else
			throw new InvalidAccountNumber("ACCOUNT NUMBER IS INVALID");
		
	}

	public void setTotalBalance(float totalBalance) {	this.totalBalance = totalBalance;	}
	
	public float getTotalBalance() {	return totalBalance;	}

	public String getAccountNumber() {	return accountNumber;	}

	public String getCustomerName() {	return customerName;	}

	public boolean isSalaryAccount() {	return isSalaryAccount;	}
	
}
