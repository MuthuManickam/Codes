package main;

public class LowBalanceException extends Exception
{
	LowBalanceException(String msg)
	{
		super(msg);
	}
}
