import java.util.*;

public class CreateEmployee 
{
	public static void main(String args[]) 
	{
		Employee e1 = new Employee("E001", "Siddharth", 500000);
		Employee e2 = new Employee("E002", "Tiyasha", 450000);
		Employee e3 = new Employee("E003", "Neetu", 400000);
		Employee e4 = new Employee("E004", "Bishakha", 350000);
		Employee e5 = new Employee("E005", "Apurwa", 300000);
		
		TreeSet ts = new TreeSet();
		
		ts.add(e1);
		ts.add(e2);
		ts.add(e3);
		ts.add(e4);
		ts.add(e5);
		
		Iterator ii = ts.iterator();
		
		while(ii.hasNext())
		{
			Employee ee = (Employee) ii.next();

			System.out.println("EMPLOYEE ID: "+ee.getEmpId());
			System.out.println("EMPLOYEE NAME : "+ee.getEmpName());
			System.out.println("EMPLOYEE SALARY : Rs. "+ee.getEmpSalary());
			System.out.println();
		}
	}
}
