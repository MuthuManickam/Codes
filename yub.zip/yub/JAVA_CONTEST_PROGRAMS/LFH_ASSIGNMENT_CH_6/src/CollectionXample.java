import java.util.*;

public class CollectionXample 
{
	public static void main(String args[]) 
	{
		HashSet hs = new HashSet();
		
		hs.add(new Integer(10));
		hs.add(new String("Sid"));
		hs.add(new Double(25.45));
		hs.add(new Boolean(true));
		hs.add(new StringBuffer("Nanda"));
		
		Iterator ii = hs.iterator();
		
		while(ii.hasNext())
		{
			Object obj = (Object) ii.next();
			System.out.println(obj);
		}
	}
}
	