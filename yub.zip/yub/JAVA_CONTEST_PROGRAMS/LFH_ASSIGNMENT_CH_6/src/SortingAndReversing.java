import java.util.*;

public class SortingAndReversing 
{
	public static void main(String args[]) 
	{
		ArrayList aa = new ArrayList();
		aa.add(new String("Smith"));
		aa.add(new String("Jones"));
		aa.add(new String("Smith"));
		aa.add(new String("Brown"));
		aa.add(new String("Able"));
		
		Collections.sort(aa);
				
		System.out.println("SORTED ORDER : ");
		for(int i=0; i<aa.size(); i++)
		{
			String ss = (String) aa.get(i);
			System.out.print(ss+"\t");
		}
			
		Collections.reverse(aa);
		System.out.println("\nREVERSE SORTED ORDER : ");
		for(int i=0; i<aa.size(); i++)
		{
			String ss = (String) aa.get(i);
			System.out.print(ss+"\t");
		}
	}
}
