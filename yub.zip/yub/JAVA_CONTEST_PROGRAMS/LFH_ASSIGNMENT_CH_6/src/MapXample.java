import java.util.*;

public class MapXample 
{
	public static void main(String args[]) 
	{
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		
		hm.put(101, "Siddharth");
		hm.put(102, "Akash");
		hm.put(103, "Tiyasha");
		
		Collection<Integer> aa = hm.keySet();
		
		for(int key : aa)
		{
			System.out.println("ID : "+key+"\tNAME : "+hm.get(key));
		}
	}
}
