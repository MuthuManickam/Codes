
public class Employee 
{
	String empId, empName;
	int empSalary;	
	
	Employee()	{	}

	Employee(String empId, String empName, int empSalary) 
	{
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
	}

	public String getEmpId() {	return empId;	}

	public void setEmpId(String empId) {	this.empId = empId;	}

	public String getEmpName() {	return empName;	}

	public void setEmpName(String empName) {	this.empName = empName;	}

	public int getEmpSalary() {	return empSalary;	}

	public void setEmpSalary(int empSalary) {	this.empSalary = empSalary;	}
}