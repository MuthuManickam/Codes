import java.util.*;

public class FindingDuplicate 
{
	public static void main(String args[]) 
	{
		String[] str = {new String("A"), new String("B"), new String("C"), new String("D"), new String("A")};
		
		Set hs = new HashSet();
		
				for(int i=0; i<str.length; i++)
		{
			if(!hs.add(str[i]))		//Set doesn't contain duplicate values
				System.out.println("DUPLICATE ELEMENT ENCOUNTERED : "+str[i]);
		}
		System.out.println(hs.size()+" DISTINCT ELEMENTS DETECTED ");
	}
}