import java.sql.Date;
import java.util.Calendar;

public class Song 
{
	private String songTitle, singer, genre;
	private int releaseYear;
	private float price;
	
	Song()	{	}
	
	Song(String songTitle, String singer, String genre, int releaseYear)
	{
		this.songTitle = songTitle;
		this.singer = singer;
		this.genre = genre;
		this.releaseYear = releaseYear;
		this.price = 10;
	}

	public String getSongTitle() {	return songTitle;	}

	public void setSongTitle(String songTitle) {	this.songTitle = songTitle;	}

	public String getSinger() {	return singer;	}

	public void setSinger(String singer) {	this.singer = singer;	}

	public String getGenre() {	return genre;	}

	public void setGenre(String genre) {	this.genre = genre;	}

	public int getReleaseYear() {	return releaseYear;	}

	public void setReleaseYear(int releaseYear) {	this.releaseYear = releaseYear;	}

	public float getPrice() {	return price;	}

	public void setPrice(float price) {	this.price = price;	}
	
	public float calculatePrice()
	{
		long milis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(milis);
		
		String dd = date.toString().substring(0, 4);
		Integer year = new Integer(dd);
		
		if(year > this.releaseYear)
		{	
			int difference = year - this.releaseYear;
			float newPrice = this.price - difference;
			
			if(newPrice < 5)
				return 5;
			else
				return newPrice;
		}
		else
			return 10;
	}
	
	public String toString()
	{
		return "\nNOW PLAYING : "+this.songTitle+"\nARTIST : "+this.singer+"\nYEAR : "+this.releaseYear+"\n";
	}
}
