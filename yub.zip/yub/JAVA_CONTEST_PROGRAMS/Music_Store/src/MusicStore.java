import java.util.*;

public class MusicStore 
{
	public static List<Song> songStore = new ArrayList<Song>();
	
	public static Song buySong(float price, Song song)	throws SongException
	{
		int flag = 0;
		for(int i=0; i<songStore.size(); i++)
		{
			Song obj = songStore.get(i);
			if(obj.getSongTitle() == song.getSongTitle() && obj.getSinger() == song.getSinger() && obj.getReleaseYear() == song.getReleaseYear() && obj.getPrice() == song.getPrice())
			{
				flag = 1;
				break;
			}
		}
		if(flag == 1)
			return song;
		else
		{
			throw new SongException("REQUESTED SONG NOT AVAILABLE.");
		}
	}
	
	public static void main(String args[])	throws SongException
	{
		try
		{
			Song s1 = new Song("Channa Mereya", "Arijit Singh", "Classical", 2016);
			Song s2 = new Song("Bojhena shey bojhena", "Arijit Singh", "Jazz", 2013);
			Song s3 = new Song("The Song of fire and ice", "Ramin Djawadi", "Instrumental", 2011);
			
			songStore.add(s1);
			songStore.add(s2);
			songStore.add(s3);
			
			User user =  new User("Sid",101);
			
			user.addSong(buySong(10,s1));
			user.addSong(buySong(10,s2));
			//user.addSong(buySong(10,new Song()));	//TRYING TO BUY THE SONG WHICH IS NOT AVAILABLE
			
			System.out.println("PRICE : Rs."+s1.calculatePrice());
			System.out.println(user.playSong(s1));
			
			System.out.println("PRICE : Rs."+s2.calculatePrice());
			System.out.println(user.playSong(s2));
			
			//System.out.println(user.playSong(s3));	//TRYING TO PLAY UNOWNED SONG
		}
		catch(Exception ee)
		{
			System.out.println(ee.getMessage());
		}
	}
}
