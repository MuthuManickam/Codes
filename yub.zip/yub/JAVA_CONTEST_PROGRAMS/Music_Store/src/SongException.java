
public class SongException extends Exception 
{
	SongException(String msg)
	{
		super(msg);
	}
}
