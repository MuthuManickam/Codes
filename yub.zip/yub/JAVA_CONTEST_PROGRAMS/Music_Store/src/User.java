import java.util.*;

public class User 
{
	private String name;
	private int id;
	private ArrayList<Song> songs = new ArrayList<Song>();
	
	User()	{	}
	
	User(String name, int id)
	{
		this.name = name;
		this.id = id;
	}
	
	public String getName() {	return name;	}
	
	public void setName(String name) {	this.name = name;	}
	
	public int getId() {	return id;	}
	
	public void setId(int id) {	this.id = id;	}
	
	public boolean addSong(Song song)	throws SongException
	{
		int flag = 0;
		for(int i=0; i<songs.size(); i++)
		{
			Song obj = songs.get(i);
			if((obj.getSongTitle().equalsIgnoreCase(song.getSongTitle())) && (obj.getSinger().equalsIgnoreCase(song.getSinger())) && (obj.getReleaseYear() == song.getReleaseYear()))
			{
				flag = 1;
				break;
			}
		}
		
		if(flag != 1)
		{
			songs.add(song);
			return true;
		}
		else
		{
			throw new SongException("USER ALREADY OWNS THIS SONG.");
		}
	}
	
	public Song playSong(Song song)	throws SongException
	{
		int flag = 0;
		for(int i=0; i<songs.size(); i++)
		{
			Song obj = songs.get(i);
			if(obj.getSongTitle() == song.getSongTitle() && obj.getSinger() == song.getSinger() && obj.getReleaseYear() == song.getReleaseYear())
			{
				flag = 1;
				break;
			}
		}
		if(flag == 1)
		{
			return song;
		}
		else
		{
			throw new SongException("SONG NOT FOUND, PLEASE BUY IT.");
		}
	}
}
