
public class StudentTest 
{
	public static void main(String args[]) 
	{
		Student ss = new Student("Siddharth", 101, 95, 98, 79, 80, 85, 74);
		
		ss.displayStudentDetails();
		ss.calculateTotalMarks();
		ss.calculateAverageMarks();
		ss.calculateGrade();
	}
}
