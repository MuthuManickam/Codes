
public class Student 
{
	String studentName, grade;
	int rollNo = 0, mathsMarks = 0, scienceMarks = 0, socialMarks = 0, englishMarks = 0, teluguMarks = 0, hindiMarks = 0, totalMarks = 0;
	double average = 0;
	
	Student()	{	}
	
		
	public Student(String studentName, int rollNo, int mathsMarks, int scienceMarks, int socialMarks, int englishMarks,int teluguMarks, int hindiMarks) 
	{
		this.studentName = studentName;
		this.rollNo = rollNo;
		this.mathsMarks = mathsMarks;
		this.scienceMarks = scienceMarks;
		this.socialMarks = socialMarks;
		this.englishMarks = englishMarks;
		this.teluguMarks = teluguMarks;
		this.hindiMarks = hindiMarks;
	}

	void calculateTotalMarks()
	{
		this.totalMarks = this.mathsMarks + this.scienceMarks + this.socialMarks + this.englishMarks + this.teluguMarks + this.hindiMarks;
		System.out.println("TOTAL MARKS : "+this.totalMarks);
	}
	
	void calculateAverageMarks()
	{
		this.average = this.totalMarks*0.16;
		System.out.println("AVERAGE MARKS : "+this.average);
	}
	
	void calculateGrade()
	{
		if(this.average >= 80 )
			grade = "DISTINCTION";
		if(this.average >= 60 && average <= 80)
			grade = "SECOND CLASS";
		if(this.average >= 50 && average <= 60)
			grade = "SECOND CLASS";
		if(this.average >= 40 && average <= 50)
			grade = "THIRD CLASS";
		if(this.average <= 40)
			grade = "FAIL";
		
		System.out.println("GRADE : "+this.grade);
	}
	
	void displayStudentDetails()
	{
		System.out.println("STUDENT'S NAME : "+this.studentName);
		System.out.println("STUDENT'S ROLL NO : "+this.rollNo);
		System.out.println("MATHS MARKS : "+this.mathsMarks);
		System.out.println("SCIENCE MARKS : "+this.scienceMarks);
		System.out.println("SOCIAL MARKS : "+this.socialMarks);
		System.out.println("ENGLSIH MARKS : "+this.englishMarks);
		System.out.println("TELUGU MARKS : "+this.teluguMarks);
		System.out.println("HINDI MARKS : "+this.hindiMarks);
	}
}
