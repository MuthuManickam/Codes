import java.util.*;

public class ShoopingCart implements CartOperations 
{
	private float tax_percentage, invoiceAmount;
	private ArrayList<Product> items = new ArrayList<Product>();
	
	public ShoopingCart(float tax_percentage) 
	{
		this.tax_percentage = tax_percentage;
	}
	
	public float getInvoiceAmount() 
	{
		return invoiceAmount;
	}

	public float addToCart(Product p) 
	{
		items.add(p);
		invoiceAmount += (p.price*p.quantity) + this.tax_percentage;
		return invoiceAmount;
	}


	public void removeFromCart(Product p) throws ProductException 
	{
		if(!items.isEmpty())
		{
			for(int i=0; i<items.size(); i++)
			{
				Product pp = (Product) items.get(i);
				if(pp.getName().equalsIgnoreCase(p.name))
				{
					invoiceAmount -= (p.getPrice()*p.getQuantity()) + this.tax_percentage;
					items.remove(i);
					System.out.println("\nPRODUCT REMOVED FROM CART SUCCESSFULLY");
				}
				else
				{
					System.out.println("\nPRODUCT NOT FOUND IN CART");
				}
			}
			
		}
		else
			throw new ProductException("CART IS EMPTY");
	}
	
	public String toString() 
	{
		String str = "";
		Iterator ii = items.iterator();
		
		if(!items.isEmpty())
		{	
			str += "\nPRODUCT NAME           QTY\n\n";
			while(ii.hasNext())
			{
				Product pp = (Product) ii.next();
				str += pp.getName()+"\t\t"+pp.getQuantity()+"\n";
			}
		}
		else
			str = "\nCART IS EMPTY";
		
		return str;
	}
	
	public static void main(String args[]) throws ProductException 
	{
		Product p1 = new Product("Keyboard", 400, 1);
		Product p2 = new Product("USB Drive", 550, 1);
		Product p3 = new Product("DSLR", 35000, 1);
		Product p4 = new Product("USB Hub\t", 100, 1);
		
		CartOperations cart = new ShoopingCart(10);
		//cart.removeFromCart(p1);
		
		cart.addToCart(p1);
		cart.addToCart(p2);
		cart.addToCart(p3);
		cart.addToCart(p4);
		cart.removeFromCart(p3);
		
		System.out.println(cart);
		System.out.println("\nTOTAL INVOICE AMOUNT : Rs."+cart.getInvoiceAmount()+"/-");
	}
}
