
public class ProductException extends Exception
{
	ProductException(String msg)
	{
		super(msg);
	}
}
