package main;

public class Employee 
{
	private int empId;
	private String empName, dateOfJoining;
	private float basicSal;
	
	public int getEmpId() {	return empId;	}
		
	public void setEmpId(int empId) throws InvalidDataException 
	{	
		if(String.valueOf(empId).length() == 4)
			this.empId = empId;
		else
			throw new InvalidDataException("EMPLOYEE ID SHOULD BE OF 4 DIGITS");
	}
	
	public String getEmpName() {	return empName;	}
	
	public void setEmpName(String empName) {	this.empName = empName;	}
	
	public String getDateOfJoining() {	return dateOfJoining;	}
	
	public void setDateOfJoining(String dateOfJoining) {	this.dateOfJoining = dateOfJoining;	}
	
	public float getBasicSal() {	return basicSal;	}
		
	public void setBasicSal(float basicSal) throws InvalidDataException 
	{
		if(basicSal >= 3000)
			this.basicSal = basicSal;
		else
			throw new InvalidDataException("EMPLOYEE SHOULD BE ATLEAST INR 3000");
	}
	
	public String toString()
	{
		return this.getEmpId()+","+this.getEmpName()+","+this.getDateOfJoining()+","+this.getBasicSal();
	}
}