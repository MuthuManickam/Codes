package main;

public class IDNotFoundException extends Exception 
{
	IDNotFoundException(String msg)
	{
		super(msg);
	}
}
