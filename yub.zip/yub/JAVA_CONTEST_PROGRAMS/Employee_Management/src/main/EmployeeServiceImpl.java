package main;

import java.util.ArrayList;

public class EmployeeServiceImpl implements EmployeeService
{
	public ArrayList<Employee> empList = new ArrayList<Employee>();
	
	public boolean addEmployee(Employee emp)
	{
		if(emp != null)
			empList.add(emp);
		
		if(empList.contains(emp))
			return true;
		else
			return false;			
	}
	
	public ArrayList<Employee> getEmployees()
	{
		if(!empList.isEmpty())
			return empList;
		else
			return null;
	}
	
	public Employee searchEmployee(int empId) throws IDNotFoundException
	{
		int flag = 0;
		Employee emp = null;
		
		for(int i=0; i<empList.size(); i++)
		{
			Employee ee = empList.get(i);
			
			if(ee.getEmpId() == empId)
			{
				emp = ee;
				flag++;
				break;
			}
		}
		
		if(flag == 1)
			return emp;
		else
			throw new IDNotFoundException("EMPLOYEE IS NOT FOUND");
	}
	
	public boolean deleteEmployee(int empId) throws IDNotFoundException
	{
		int flag = 0;
		boolean delete = false;
		
		for(int i=0; i<empList.size(); i++)
		{
			Employee ee = empList.get(i);
			
			if(ee.getEmpId() == empId)
			{
				empList.remove(ee);
				delete = true;
				flag++;
				break;
			}
		}
		
		if(flag == 1)
			return delete;
		else
			throw new IDNotFoundException("EMPLOYEE IS NOT FOUND");
	}
	
	public float calculateIncentive(float basicSal)
	{
		float incentive = 0;
		
		if(basicSal >= 3000 && basicSal < 5000)
			incentive = basicSal * 0.05f;
		else if(basicSal >= 5000 && basicSal < 10000)
			incentive = basicSal * 0.08f;
		else if(basicSal >= 10000)
			incentive = basicSal * 0.1f;
		
		return incentive;
	}
}
