package main;

public class InvalidDataException extends Exception 
{
	InvalidDataException(String msg)
	{
		super(msg);
	}
}
