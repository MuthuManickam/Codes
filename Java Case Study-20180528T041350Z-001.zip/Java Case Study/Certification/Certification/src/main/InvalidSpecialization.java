package main;

public class InvalidSpecialization extends Exception{

	private static final long serialVersionUID = 1L;
	
	String err;

	public InvalidSpecialization(String err) {
		super(err);
	}
	
	
}
