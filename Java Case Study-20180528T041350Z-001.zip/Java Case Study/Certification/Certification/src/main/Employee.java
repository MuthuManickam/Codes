package main;
import java.util.ArrayList;

public class Employee {
	@SuppressWarnings("unused")
	private int eid;
	@SuppressWarnings("unused")
	private String eName;
	@SuppressWarnings("unused")
	private String specialization;
	
	private ArrayList<String> myCertifications = new ArrayList<String>();

	public ArrayList<String> getMyCertifications() {
		return myCertifications;
	}

	public Employee(int eid, String eName, String specialization) throws InvalidSpecialization {
		if(specialization.equals("JAVA") || (specialization.equals("ORACLE"))) {
			this.eid = eid;
			this.eName = eName;
			this.specialization = specialization;
		} else {
			throw new InvalidSpecialization("Specialization is invalid!");
		}
		
	}
	
	
	
	
	
	
	
	
	
	
}
