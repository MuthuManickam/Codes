package main;

public class InvalidCertificationCode extends Exception{

	private static final long serialVersionUID = 1L;
	
	String msg;

	public InvalidCertificationCode(String msg) {
		super(msg);
	}
	
	
}
