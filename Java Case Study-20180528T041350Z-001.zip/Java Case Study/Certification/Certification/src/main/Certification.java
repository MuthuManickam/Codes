package main;

public class Certification {
	private String certCode;
	private int fees;
	
	public String getCertCode() {
		return certCode;
	}
	
	public int getFees() {
		return fees;
	}
	
	
	public void setCertCode(String certCode) {
		this.certCode = certCode;
	}
	
	public void setFees(int fees) {
		this.fees = fees;
	}
	
	
}
