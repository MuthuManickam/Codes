package main;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class CertificationMaster {
	

	public HashMap<String, Integer> certificationDetails = new HashMap<String, Integer>();
	Set<String> s = certificationDetails.keySet();
	//Collection e = certificationDetails.values();
	
	
	public void addCertification(Certification c) {
		certificationDetails.put(c.getCertCode(),c.getFees());
	}
	
	
	public int getCertificationFees(String certCode) throws InvalidCertificationCode {
		int flag = 0;
		int certFees  = 0;
		Iterator<String> it = s.iterator();
		
		while(it.hasNext()) {
			String key = it.next();
			certFees =  certificationDetails.get(key);
			if(key.equals(certCode)) {
				flag = 1;
				break;
			} 
		}
		if(flag == 1) {
			return certFees;
		}else {
			throw new InvalidCertificationCode("Invalid code");
		}
	}
	
	
	
	public void bookCertification(String certCode, Employee e) {
		e.getMyCertifications().add(certCode);
		
	}
	
	
	public int claimReimbursement(Employee e) {
		int amt=0;
		int totalCost=0;
		Iterator<String> it1 = s.iterator();
		while(it1.hasNext())
		 {
			String certificateCode=(String) it1.next();
			amt = certificationDetails.get(certificateCode);
			
			for(int i=0; i<e.getMyCertifications().size(); i++) {
				String cert = e.getMyCertifications().get(i);
				if(certificateCode.equals(cert)) {
					totalCost = totalCost + amt;
				}
			}	
		}
		return totalCost;
	}
	
	public static void main(String[] args) throws InvalidCertificationCode, InvalidSpecialization {
		
			
				try {
					Employee e1 = new Employee(1, "Debanita", "JAVA");
					//Employee e1 = new Employee(1, "Debanita", "MAINFRAME"); //InvalidSpecialization
					
					Certification c1 = new Certification();
					c1.setCertCode("1Z0-148");
					c1.setFees(10000);
					
					Certification c2 = new Certification();
					c2.setCertCode("1Z0-061");
					c2.setFees(9000);
					
					Certification c3 = new Certification();
					c3.setCertCode("1Z0-803");
					c3.setFees(11000);
					
					
					CertificationMaster cm = new CertificationMaster();
					cm.addCertification(c1);
					cm.addCertification(c2);
					cm.addCertification(c3);
					
					System.out.println(cm.getCertificationFees("1Z0-148"));  //10000
					System.out.println(cm.getCertificationFees("1Z0-061"));  //9000
					System.out.println(cm.getCertificationFees("1Z0-803"));   //11000
					//cm.getCertificationFees("ORA-123"); //InvalidCertificationCode
					
					
					cm.bookCertification("1Z0-061", e1);
					System.out.println(e1.getMyCertifications().contains("1Z0-061"));  //true
					cm.bookCertification("1Z0-148", e1);
					System.out.println(cm.claimReimbursement(e1));  //19000;
				} catch (InvalidCertificationCode e) {
					
					e.printStackTrace();
				} catch(InvalidSpecialization e) {
					e.printStackTrace();
				}
			
		
		
	
	}
	
}
