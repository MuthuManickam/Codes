import java.io.File;
import java.util.ArrayList;

import com.beans.Requirement;
import com.train.Training;


public class TestMain {
	@SuppressWarnings("unused")
	public static void main(String[] args) {

		Training t = new Training();
		File f = new File("F:\\Java_programs\\IT_Training1\\Company.txt");

		ArrayList<Requirement> ar = t.fillList(f);
		t.setTrainer();
		int x = t.courses();
		System.out.println("Courses : " + x);

		ArrayList<Requirement> spec = t.specific("Advanced");

		for (int i = 0; i < spec.size(); i++) {
			System.out.println(spec.get(i));
		}
		Training tr = new Training();

		ArrayList<Requirement> err = tr.fillList(new File("F:\\Java_programs\\IT_Training1\\faulty.txt"));
	}
}
