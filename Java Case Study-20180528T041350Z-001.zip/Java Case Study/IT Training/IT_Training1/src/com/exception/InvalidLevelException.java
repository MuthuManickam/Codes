package com.exception;

public class InvalidLevelException extends Exception {

	private static final long serialVersionUID = 1L;
	
	String msg;

	public InvalidLevelException(String msg) {
		super(msg);
	}
	
	
}
