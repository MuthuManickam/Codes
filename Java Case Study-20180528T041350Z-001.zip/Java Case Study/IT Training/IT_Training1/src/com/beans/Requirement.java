package com.beans;
import com.exception.InvalidLevelException;


public class Requirement {
	private String program;
	private String level;
	private int empCount;
	private String date;
	private String trainer;
	
	public Requirement(String program, String level, int empCount, String date) throws InvalidLevelException{
		if(level.equalsIgnoreCase("Beginner") || level.equalsIgnoreCase("Intermediate") || level.equalsIgnoreCase("Advanced")) {
			this.program = program;
			this.level = level;
			this.empCount = empCount;
			this.date = date;
		} else {
			throw new InvalidLevelException("Level is invalid!");
		}	
	}

	public String getProgram() {
		return program;
	}

	public String getLevel() {
		return level;
	}

	public int getEmpCount() {
		return empCount;
	}

	public String getDate() {
		return date;
	}

	public String getTrainer() {
		return trainer;
	}

	public void setProgram(String program) {
		this.program = program;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public void setEmpCount(int empCount) {
		this.empCount = empCount;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setTrainer(String trainer) {
		this.trainer = trainer;
	}

	@Override
	public String toString() {
		return "program = " + program + ",  level = " + level
				+ ",  empCount = " + empCount + ",  date = " + date + ",  trainer = "
				+ trainer;
	}
	
	
	
}
