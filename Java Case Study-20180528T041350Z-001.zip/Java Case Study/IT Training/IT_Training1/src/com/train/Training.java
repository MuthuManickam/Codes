package com.train;
import java.io.*;
import java.util.ArrayList;

import com.beans.Requirement;
import com.exception.InvalidLevelException;


public class Training {
	
	private ArrayList<Requirement> training = new ArrayList<Requirement>();

	public ArrayList<Requirement> fillList(File file) {
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String str;
			while((str=br.readLine())!=null) {
				String[] content = str.split(":");
				Requirement requirement = new Requirement(content[0], content[1], Integer.parseInt(content[2]), content[3]);
				training.add(requirement);
			}
			br.close();
		} catch (NumberFormatException | IOException | InvalidLevelException e) {
			e.printStackTrace();
		}
		return training;
	}
	
	
	public ArrayList<Requirement> setTrainer() {
		for(Requirement req : training) {
			if(req.getProgram().equalsIgnoreCase("Java Programming")) {
				req.setTrainer("Amit");
			} else if(req.getProgram().equalsIgnoreCase("JEE Programming")) {
				req.setTrainer("Gita");
			} else if(req.getProgram().equalsIgnoreCase("AngularJS")) {
				req.setTrainer("Aswin");
			} else if(req.getProgram().equalsIgnoreCase("MongoDb")) {
				req.setTrainer("Monica");
			} 
		}
		return null;
	}
	
	
	public ArrayList<Requirement> specific(String level) {
		ArrayList<Requirement> al = new ArrayList<Requirement>();
		for(Requirement req : training) {
			if(req.getLevel().equalsIgnoreCase(level)){
				al.add(req);
			}
		}
		return al;
	}
	
	
	/*@SuppressWarnings("unused")
	public int courses() {
		int count = 0;
		for(Requirement req : training) {
			count++;
		}
		return count;
	}*/
	
	
	public int courses() {
		int count = 0;
		for(int i=0; i<training.size(); i++) {
			for(int j=i+1; j<training.size(); j++) {
				Requirement course1 = training.get(i);
				Requirement course2 = training.get(j);
				if(course1.getProgram().equalsIgnoreCase(course2.getProgram())) 
					count++;
			}
		}
		return training.size()-count;
	}

	public ArrayList<Requirement> getTraining() {
		return training;
	}


	public void setTraining(ArrayList<Requirement> training) {
		this.training = training;
	}	
	
}
