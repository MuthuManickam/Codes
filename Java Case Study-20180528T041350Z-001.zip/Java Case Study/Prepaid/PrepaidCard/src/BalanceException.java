
public class BalanceException extends Exception {
	
	private static final long serialVersionUID = 1L;
	String msg;
	
	public BalanceException(String msg) {
		this.msg = msg;
	}
	
}
