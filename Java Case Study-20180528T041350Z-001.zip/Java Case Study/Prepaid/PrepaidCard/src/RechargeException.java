
public class RechargeException extends Exception{
	
	private static final long serialVersionUID = 1L;
	String error;
	
	public RechargeException(String error) {
		this.error = error;
	}
	
}
