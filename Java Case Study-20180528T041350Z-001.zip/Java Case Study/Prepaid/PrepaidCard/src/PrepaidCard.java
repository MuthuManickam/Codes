
public class PrepaidCard implements PrepaidCalling{
	
	private int balance;
	private int minsUsed;
	float amount;
	
	public PrepaidCard(int balance) {
		this.balance = balance;
	}

	public int rechargeCard(int rupees) throws RechargeException{
		if(rupees <=1000){
			return balance = balance + rupees;
		}
		else{
			throw new RechargeException("Recharge Exception !");
		}
	}
	
	public float useCard(int mins) throws BalanceException{
		 amount = mins*PrepaidCalling.RATE;
		 if(amount <= balance){
			 balance =  (int) (balance -  amount);
			 return amount;
		 }
		 else{
			 throw new BalanceException("Less Balance!");
		 }
	}
	
	public float getBalanceAmount(){
		return balance;
	}
	
	public int getUsage(){
		minsUsed = (int) (amount/PrepaidCalling.RATE);
		return minsUsed;
	}
	public int getBalanceMins(){
		return (int) (balance/PrepaidCalling.RATE);
	}



	public static void main(String[] args) throws BalanceException, RechargeException{
	
		PrepaidCalling pc = new PrepaidCard(500);
		//pc.rechargeCard(1500);           //RechargeException
		System.out.println(pc.getBalanceAmount());   //500.0
		pc.useCard(10);
		//pc.useCard(600); //BalanceException
		System.out.println(pc.getBalanceAmount());  //485.0
		System.out.println(pc.getUsage());  //10
		System.out.println(pc.getBalanceMins());  //323
		
		pc.rechargeCard(100);
		System.out.println(pc.getBalanceAmount());   //585.0
		System.out.println(pc.getBalanceMins());   //390
		
		
	}

}
