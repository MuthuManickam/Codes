
public interface PrepaidCalling {
	public float RATE = 1.5f;
	
	public int rechargeCard(int rupees) throws RechargeException;
	public float useCard(int mins) throws BalanceException;
	public float getBalanceAmount();
	public int getUsage();
	public int getBalanceMins();
}
