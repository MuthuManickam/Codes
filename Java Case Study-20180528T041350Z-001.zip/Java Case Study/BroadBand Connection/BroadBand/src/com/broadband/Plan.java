package com.broadband;

public class Plan {
	private String planName;
	private String planType;
	private int baseCharge;
	
	
	public Plan(String planName, String planType, int baseCharge) throws InvalidPlanTypeException {
		if(planType.equals("LimitedPlan") || planType.equals("UnlimitedPlan")) {
			this.planType = planType;	
			this.planName = planName;
			this.baseCharge = baseCharge;
		}else {
			throw new InvalidPlanTypeException("Invalid Plan!");
		}
		
	}

	public String getPlanName() {
		return planName;
	}

	public String getPlanType() {
		return planType;
	}

	public int getBaseCharge() {
		return baseCharge;
	}	
	
}
