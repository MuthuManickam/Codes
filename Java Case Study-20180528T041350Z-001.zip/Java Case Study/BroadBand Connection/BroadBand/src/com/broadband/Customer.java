package com.broadband;

public class Customer {
	private int custId;
	private String custName;
	private Plan plan;
	private int dataUsage;
		
	public Customer(int custId, String custName, int dataUsage) {
		this.custId = custId;
		this.custName = custName;
		this.dataUsage = dataUsage;
	}

	public int getCustId() {
		return custId;
	}

	public String getCustName() {
		return custName;
	}

	public int getDataUsage() {
		return dataUsage;
	}
	
	
	public Plan getPlan() {
		return plan;
	}

	public void setPlan(Plan plan) {
			this.plan = plan;
		
	}
	
	public int getBill() {
		int amount = 0;
		if(plan.getPlanName().equals("SUPER_LIM_10")) {
			if(dataUsage <=10) {
				amount = plan.getBaseCharge();
			}else {
				amount = plan.getBaseCharge() + (dataUsage-10)*25;
			}
			
		}
		 if(plan.getPlanName().equals("SUPER_LIM_20")) {
			if(dataUsage <=20) {
				amount = plan.getBaseCharge();
			}else {
				amount = plan.getBaseCharge() + (dataUsage-20)*35;
			}
		}
		 if(plan.getPlanName().equals("SUPER_UNLIM_20")) {
			 amount = plan.getBaseCharge();
		 }
		 return amount;
	}

		
}
