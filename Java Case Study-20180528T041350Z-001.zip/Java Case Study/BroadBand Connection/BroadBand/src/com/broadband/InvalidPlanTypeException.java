package com.broadband;

public class InvalidPlanTypeException extends Exception {

	private static final long serialVersionUID = 1L;
	
	String msg;

	public InvalidPlanTypeException(String msg) {
		super(msg);
	}
	
	
}
