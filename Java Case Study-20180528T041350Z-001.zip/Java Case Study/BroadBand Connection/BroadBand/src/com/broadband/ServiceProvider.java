package com.broadband;
import java.util.ArrayList;

public class ServiceProvider implements BroadbandConnection {
	public ArrayList<Customer> custDetails = new ArrayList<Customer>();
	
	public boolean activate(Customer c) {
		custDetails.add(c);
		if(custDetails.contains(c)) {
			return true;
		}else {
			return false;
		}
	}
	
	
	public boolean deActivate(Customer c) {
		if(custDetails.contains(c)) {
			custDetails.remove(c);
			return true;
		}else {
			return false;
		}
	}
	
	
	public int getCountByPlanType(String planType) {
		int count = 0;
		for(Customer cust:custDetails) {
			if(cust.getPlan().getPlanType().equals(planType)) {
				count++;
			}
		}
		return count;	
	}
	
	
	public int getCountByPlanName(String planName) {
		int CountByPlanName = 0;
		for(Customer cust:custDetails) {
			if(cust.getPlan().getPlanName().equals(planName)) {
				CountByPlanName++;
			}
		}
		return CountByPlanName;	
	}
}
