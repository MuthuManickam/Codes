package com.broadband;

public class Main {
	
	public static void main(String[] args) throws InvalidPlanTypeException {
		try {
			Plan p1 = new Plan("SUPER_LIM_10", "LimitedPlan", 200);
			Customer c1 = new Customer(101, "Alex Paris", 10);
			c1.setPlan(p1);
			int billForC1 = c1.getBill();
			System.out.println("Bill for Alex : "+billForC1);
			
			
			Plan p2 = new Plan("SUPER_LIM_20", "LimitedPlan", 400);
			Customer c2 = new Customer(102, "Shweta Kumari", 24);
			c2.setPlan(p2);
			int billForC2 = c2.getBill();
			System.out.println("Bill for Shweta : "+billForC2);

			
			Plan p3 = new Plan("SUPER_UNLIM_20", "UnlimitedPlan", 500);
			Customer c3 = new Customer(103, "Devesh Joshi", 22);
			c3.setPlan(p3);
			int billForC3 = c3.getBill();
			System.out.println("Bill for Devesh : "+billForC3);
			
			//activate / provide service to customer and display details
			
			ServiceProvider p = new ServiceProvider();
			p.activate(c1);
			p.activate(c2);
			p.activate(c3);
			
			int CountByPlanType = p.getCountByPlanType("LimitedPlan");
			System.out.println("CountByPlanType for LimitedPlan : "+CountByPlanType);
			
			int CountByPlanName = p.getCountByPlanName("SUPER_LIM_20");
			System.out.println("CountByPlanName for SUPER_LIM_20 : "+CountByPlanName);
			
			//deactivate the customer
			p.deActivate(c1);
			
			//Plan p5 = new Plan("15Mbps", "limitedPlan", "12", 1, 800);
			
		}catch(InvalidPlanTypeException e) {
			System.out.println(e.getMessage());
		}
			
		
	}

}
