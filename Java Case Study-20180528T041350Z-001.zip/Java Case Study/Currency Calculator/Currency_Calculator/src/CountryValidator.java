
public class CountryValidator {
	public static String[] countries = {"US", "UK", "Europe", "Singapore", "Japan"};
	
	boolean validateCountry(String country) {
		int flag = 0;
		for(int i=0; i<countries.length; i++) {
			if(country.equalsIgnoreCase(countries[i])) {
				flag = 1;
			}
		}
		if(flag == 1) {
			return true;
		} else {
			return false;
		}
	}
}
