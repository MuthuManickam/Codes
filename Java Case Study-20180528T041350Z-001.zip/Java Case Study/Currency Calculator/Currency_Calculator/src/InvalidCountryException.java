
public class InvalidCountryException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	String msg;

	public InvalidCountryException(String msg) {
		super(msg);
	}
	
	
}
