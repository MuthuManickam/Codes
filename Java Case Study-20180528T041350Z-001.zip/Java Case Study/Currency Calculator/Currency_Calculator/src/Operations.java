import java.util.ArrayList;
import java.util.Collections;



public class Operations {
	@SuppressWarnings("unused")
	private int amountInRupees;
	
	private ArrayList<Currency> currency = new ArrayList<Currency>();

	public ArrayList<Currency> getCurrency() {
		return currency;
	}
	
	
	public void addToList(Currency c) {
		currency.add(c);
	}
	
	public float convertIntoRupee(String country, int amountInRupees) throws InvalidCountryException {
		float convertedRupees = 0.0f;
		int flag = 0;
		for(Currency curr : currency) {
			if(curr.getCountryName().equalsIgnoreCase(country)) {
				convertedRupees = amountInRupees * (curr.getRateInRupee());
				flag = 1;
			}
		}
		if(flag == 1) {
			return convertedRupees;
		} else {
			throw new InvalidCountryException("Invalid Country!");
		}
	}
	
	
	public String getCurrencyByCountryName(String country) {
		String getCurrency = "";
		for(Currency curr : currency) {
			if(curr.getCountryName().equalsIgnoreCase(country)) {
				getCurrency = curr.getCurrencyName();
			} 
		}
		return getCurrency;
	}
	
	/*public float getMinValue() {
		ArrayList<Float> rates = new ArrayList<Float>();
		for(Currency cc :currency) {
			rates.add(cc.getRateInRupee());
		}
		Collections.sort(rates);
		return rates.get(0);
	}*/
	
	public float getMinValue() {
		float minVal = 0.0f;
		ArrayList<Float> rates = new ArrayList<Float>();
		for(Currency cc :currency) {
			rates.add(cc.getRateInRupee());
		}
		minVal = Collections.min(rates);
		return minVal;
	}
}
