
public class Currency {
	private String countryName;
	private String currencyName;
	private float rateInRupee;
	
	CountryValidator cv = new CountryValidator();
	
	public Currency(String countryName, String currencyName, float rateInRupee) throws InvalidCountryException{
		if(cv.validateCountry(countryName)) {
			this.countryName = countryName;
			this.currencyName = currencyName;
			this.rateInRupee = rateInRupee;
		} else {
			throw new InvalidCountryException("country name is invalid!");
		}
		
	}

	public String getCountryName() {
		return countryName;
	}

	public String getCurrencyName() {
		return currencyName;
	}

	public float getRateInRupee() {
		return rateInRupee;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}

	public void setRateInRupee(float rateInRupee) {
		this.rateInRupee = rateInRupee;
	}
	
	
	
	
}
