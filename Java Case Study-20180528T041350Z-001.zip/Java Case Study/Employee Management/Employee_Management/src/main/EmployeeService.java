package main;

import java.util.ArrayList;

public interface EmployeeService {
	
	public boolean addEmployee(Employee emp);
	public ArrayList<Employee> getEmployees();
	public Employee searchEmployee(int empId)throws IDNotFoundException;
	public boolean deleteEmployee(int empId) throws IDNotFoundException;
	public float calculateincentive(float basicSal);
}
