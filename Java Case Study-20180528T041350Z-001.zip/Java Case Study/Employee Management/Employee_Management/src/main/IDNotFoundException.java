package main;

public class IDNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String msg;
	public IDNotFoundException(String msg) {
		super(msg);
	}
	
}
