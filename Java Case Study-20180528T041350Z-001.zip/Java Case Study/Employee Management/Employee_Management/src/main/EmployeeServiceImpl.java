package main;

import java.util.ArrayList;

public class EmployeeServiceImpl implements EmployeeService{
	
	public ArrayList<Employee> empList = new ArrayList<Employee>();
	
	public boolean addEmployee(Employee emp) {
		empList.add(emp);
		if(empList.contains(emp)) {
			return true;
		} else {
			return false;
		}
		
	}
	
	@SuppressWarnings("unused")
	public ArrayList<Employee> getEmployees() {
		int flag = 0;
		for(Employee e : empList) {
			flag = 1;
		}
		if(flag == 1) {
			return empList;
		} else {
			return null;
		}		
	}
	
	
	public Employee searchEmployee(int empId) throws IDNotFoundException {
		int flag = 0;
		Employee employee = null;
		for(Employee e : empList) {
			if(e.getEmpId() == empId) {
				flag = 1;
				employee = e;
				break;
			}
		}
			if(flag == 1) {
				return employee;
			} else {
				throw new IDNotFoundException("ID not found!");
			}
	}
	
	
	public boolean deleteEmployee(int empId) throws IDNotFoundException {
		int flag = 0;
		for(Employee e : empList) {
			if(e.getEmpId() == empId) {
				empList.remove(e);
				flag = 1;
				break;
			}
		}
		if(flag == 1) {
			return true;
		} else {
			throw new IDNotFoundException("Employee ID to be deleted was not found!");
		}
	}
	
	public float calculateincentive(float basicSal) {
		float incentives = 0.0f;
		if(basicSal >= 3000 && basicSal < 5000) {
			incentives = 5 * (basicSal/100);
		} else if(basicSal >= 5000 && basicSal < 10000) {
			incentives = 8 * (basicSal/100);
		} else if(basicSal >= 10000) {
			incentives = 10 * (basicSal/100);
		}
		return incentives;
	}
}
