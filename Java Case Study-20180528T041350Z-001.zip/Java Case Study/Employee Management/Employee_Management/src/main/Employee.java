package main;

public class Employee {
	private int empId;
	private String empName;
	private String dateOfjoining;
	private float basicSal;
	
	public void setEmpId(int empId) throws InvalidDataException {
		String str = String.valueOf(empId);
		if(str.length()==4) {
			this.empId = empId;
		} else {
			throw new InvalidDataException("Invalid data!");
		}
		
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public void setDateOfjoining(String dateOfjoining) {
		this.dateOfjoining = dateOfjoining;
	}
	public void setBasicSal(float basicSal) throws InvalidDataException {
		if(basicSal >= 3000) {
			this.basicSal = basicSal;
		} else {
			throw new InvalidDataException("Invalid data!");
		}
	}
	
	
	public int getEmpId() {
		return empId;
	}
	public String getEmpName() {
		return empName;
	}
	public String getDateOfjoining() {
		return dateOfjoining;
	}
	public float getBasicSal() {
		return basicSal;
	}
	@Override
	public String toString() {
		return "empId:" + empId + ",  empName:" + empName
				+ ",  dateOfjoining:" + dateOfjoining + ",  basicSal:" + basicSal+"\n";
	}
	
	
	
	
	
	
	
	
}
