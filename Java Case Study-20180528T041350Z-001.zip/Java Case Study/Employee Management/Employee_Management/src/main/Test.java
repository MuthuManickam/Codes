package main;

import java.util.List;

public class Test {
	public static void main(String[] args) throws InvalidDataException, IDNotFoundException {
		
		Employee emp1 = new Employee();
		emp1.setEmpId(1001);
		emp1.setEmpName("Rohit");
		emp1.setDateOfjoining("23/12/2009");
		emp1.setBasicSal(6456);
		
		
		Employee emp2 = new Employee();
		emp2.setEmpId(1002);
		emp2.setEmpName("geeta");
		emp2.setDateOfjoining("3/1/2009");
		emp2.setBasicSal(7856);
		
		
		EmployeeService calc = new EmployeeServiceImpl();
		boolean r1 = calc.addEmployee(emp1);
		boolean r2 = calc.addEmployee(emp2);
		System.out.println("Calling addEmployee method = "+ r1+" "+r2);
		
		List<Employee> empList = calc.getEmployees();
		System.out.println(empList);
		
		Employee emp = calc.searchEmployee(1001);
		System.out.println("Employee found:\n"+emp);
		
		boolean res = calc.deleteEmployee(1002);
		System.out.println("Calling deleteEmployee method = "+res);
		
		float incentive = calc.calculateincentive(5678);
		System.out.println("Incentive = "+incentive);  //454.24
		
		
	}
}
