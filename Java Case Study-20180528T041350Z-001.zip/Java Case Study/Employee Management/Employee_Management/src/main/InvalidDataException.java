package main;

public class InvalidDataException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String str;
	public InvalidDataException(String str) {
		super(str);
	}
	
	
}
