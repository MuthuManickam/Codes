package com.shop;

public class InvalidProductId extends Exception {

	private static final long serialVersionUID = 1L;
	
	String msg;

	public InvalidProductId(String msg) {
		super(msg);
	}
	
	
}
