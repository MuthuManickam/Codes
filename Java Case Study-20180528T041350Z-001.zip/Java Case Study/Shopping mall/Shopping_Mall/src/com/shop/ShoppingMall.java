package com.shop;
import java.util.ArrayList;

public class ShoppingMall {
	private ArrayList<Customer> custList = new  ArrayList<Customer>();
	
	
	public void addCustomer(Customer customer) {
		custList.add(customer);
	}
	
	
	public boolean searchCustomer(Customer customer) throws NotARegisteredCustomer {
		int flag = 0;
		for(Customer cust:custList) {
			if((cust.getCustId()==customer.getCustId()) && (cust.getCustName().equals(customer.getCustName()))) {
				flag = 1;
				break;
			}
		}
		if(flag == 1) {
			return true;
		}else {
			throw new NotARegisteredCustomer("This customer is not registerd!");
		}
	}
	
	
	// This blocked method is showing error so don't use this
	/*public boolean searchCustomer(Customer customer) throws NotARegisteredCustomer  {
		if(custList.contains(customer)) {
			return true;
		} else {
			throw new NotARegisteredCustomer("This customer is not registerd!");
		}
	}*/
	
	
	/*@SuppressWarnings("unused")
	public int getTotalCustomerCount() {
		int count = 0;
		for(Customer cust:custList) {
			count++;
		}
		return count;
	}*/
	
	
	public int getTotalCustomerCount() {
		int count = 0;
		for(int i=0; i<custList.size(); i++) {
			count++;
			}
		return count;
		}
		
	



	public static void main(String[] args) {
		
		ShoppingMall mall = new ShoppingMall();
		mall.addCustomer(new Customer(2323,"Harish"));
		mall.addCustomer(new Customer(577,"Radha"));
		mall.addCustomer(new Customer(888,"Amit"));
		System.out.println("Total Registered Customer are : "+mall.getTotalCustomerCount());   //3
		
		Customer newCustomer = new Customer(577,"Radha");  //Line 1
		//Customer newCustomer = new Customer(346,"Shweta");  // line 2
		//Comment Line1 and Uncomment Line2 , It should throw an exception as user is not registered
		
		try {
			//if customer is registered allow him to shop
			
			if(mall.searchCustomer(newCustomer)== true) {
				newCustomer.shop(new Product("E101", "TV", 15000));
				newCustomer.shop(new Product("N102", "Table", 7000));   //Line 3
				//newCustomer.shop(new Product("S102", "TV", 15000));   //Line4
				/*If line 3 is commented and Line 4 is uncommented,
				it should throw exception as InvalidProductId     */
				
				System.out.println("Total Bill = "+newCustomer.generateBill() );   // 22000.0
			}
			}catch(NotARegisteredCustomer e) {
				e.printStackTrace();
			}catch(InvalidProductId e) {
				e.printStackTrace();
			}
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
}
