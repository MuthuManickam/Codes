package com.shop;

public class Product {
	private String productId;
	private String productName;
	private float productPrice;
	
	public String getProductId() {
		return productId;
	}
	public String getProductName() {
		return productName;
	}
	public float getProductPrice() {
		return productPrice;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}
	
	
	public Product(String productId, String productName, float productPrice) throws InvalidProductId {
		this.productName = productName;
		this.productPrice = productPrice;
		if(productId.startsWith("E") || productId.startsWith("N")) {
			this.productId = productId;
		}else {
			throw new InvalidProductId("Product Id is Invalid!");
		}
	}
	
	
	
	
	
	
	
	
	
}
