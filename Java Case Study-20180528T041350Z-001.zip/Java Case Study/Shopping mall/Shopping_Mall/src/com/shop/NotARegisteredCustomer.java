package com.shop;

public class NotARegisteredCustomer extends Exception{

	private static final long serialVersionUID = 1L;
	
	String error;

	public NotARegisteredCustomer(String error) {
		super(error);
	}
	
	
}
