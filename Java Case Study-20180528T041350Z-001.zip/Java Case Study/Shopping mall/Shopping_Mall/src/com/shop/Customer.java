package com.shop;
import java.util.Vector;

public class Customer {
	private int custId;
	private String custName;
	
	private Vector<Product> items = new Vector<Product>();

	public int getCustId() {
		return custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	
	public Customer(int custId, String custName) {
		this.custId = custId;
		this.custName = custName;
	}
	
	
	public boolean shop(Product selectedProduct) {
		if(selectedProduct.getProductId().startsWith("E") || selectedProduct.getProductId().startsWith("N")) {
			items.add(selectedProduct);
			return true;
		}else {
			return false;
		}
		
		/*if(items.add(selectedProduct)) {
			return true;
		}else {
			return false;
		}*/
	}
	
	public float generateBill() {
		float totalBill = 0.0f;
		for(Product prod:items) {
			totalBill = totalBill + prod.getProductPrice();
		}
		return totalBill;
	}
	
}
